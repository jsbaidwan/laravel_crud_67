<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TourPackage extends Model
{
    //
    protected $fillable = [
        'title','location', 'price', 'currency_type', 'inclusion', 'exclusion','duration','status','departure_date',
    ];
}
