<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use View;
use App\Customer;
use App\TourPackage;
use App\BookedFlight;
use Session;
use Redirect;
use Validator;
use File;
use Config;
use Response;
class customers_controller extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    ####### FUNCTION TO SHOW LIST OF CUSTOMERS #######
    function index(Request $request) {
        $customers_arr = Customer::orderby('created_at', 'desc')->get();
        return View::make('customers.index')->with('customers_arr', $customers_arr);
    }

    ####### FUNCTION TO RENDER ADD/EDIT CUSTOMER FORM #######
    function add_customer(Request $request, $id=null) {
        $customer_data = array();
        if(!empty($id)) {
            $customer_data = Customer::where('id', $id)->first();
        }
        return View::make('customers.add_customer')->with('customer_data', $customer_data);
    }

    ####### FUNCTION TO SAVE CUSTOMER DETAILS #######
    function save_customer(Request $request) {
        $data = $request->all();
        unset($data['_token']);
        if(isset($data['id']) && !empty($data['id'])) {
            $validator = Validator::make($request->all(), [ 
                'first_name' => 'required',
                //'email' => 'unique:customers,email,'.$data['id'],
                'phone' => 'required|regex:/[0-9]{9}/|unique:customers,phone,'.$data['id'],  
            ]);  
            if($validator->fails()) 
            {          
                return Redirect::back()->withInput($request->all())->withErrors($validator);    
            }
            else 
            {
                $customer_data = Customer::where('id', $data['id'])->first();
                if(!empty($data['dob']) && empty($customer_data->dob)) {
                    $data['birthday_reminder'] = get_reminder_date($data['dob']);
                }
                if(!empty($data['marriage_anniversary']) && empty($customer_data->marriage_anniversary)) {
                    $data['anniversary_reminder'] = get_reminder_date($data['marriage_anniversary']);
                }
                if(Customer::where('id', $data['id'])->update($data)) {
                    Session::flash('success', 'Customer has been updated successfully.');
                    return Redirect('/customers');                
                }   
                {
                    Session::flash('error', 'An error occured while saving customer detail.');
                    return Redirect::back()->withInput($request->all());            
                }
            }
        }
        else {
            $validator = Validator::make($request->all(), [ 
                'first_name' => 'required',
                //'email' => 'unique:customers',
                'phone' => 'required|regex:/[0-9]{9}/|unique:customers',  
            ]);  
            if($validator->fails()) 
            {          
                return Redirect::back()->withInput($request->all())->withErrors($validator);    
            }
            else 
            {
                if(!empty($data['dob'])) {
                    $data['birthday_reminder'] = get_reminder_date($data['dob']);
                }
                if(!empty($data['marriage_anniversary'])) {
                    $data['anniversary_reminder'] = get_reminder_date($data['marriage_anniversary']);
                }
                //echo '<pre>';print_r($data);die;
                if(Customer::create($data)) {
                    $phone_numbers = $data['phone'];
                    //Your authentication key
                    $authKey = Config::get('constants.SMS_API_AUTH_KEY');
                    //Multiple mobiles numbers separated by comma
                    //$mobileNumber = "9779991525,6284323217";
                    $mobileNumber = $phone_numbers;
                    //Sender ID,While using route4 sender id should be 6 characters long.
                    $senderId = Config::get('constants.SMS_API_SENDER_ID');
                    //Your message to send, Add URL encoding here.
                    $message = 'Welcome To Evergreen Travels.';
                    
                    //Define route 
                    $route = config::get('constants.SMS_API_ROUTE_ID');
                    //Prepare you post parameters
                    $postData = array(
                        'authkey' => $authKey,
                        'number' => $mobileNumber,
                        'message' => $message,
                        'senderid' => $senderId,
                        'route' => $route,
                        'username' => config::get('constants.SMS_API_USER_NAME'),
                        'password' => config::get('constants.SMS_API_PASSWORD')
                    );
                    //API URL
                    $url = config::get('constants.SMS_API_URL');
                    // init the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => $postData
                        //,CURLOPT_FOLLOWLOCATION => true
                    ));
                    //Ignore SSL certificate verification
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    //get response
                    $output = curl_exec($ch);
                    //Print error if any
                    if (curl_errno($ch)) {
                        Session::flash('error', curl_error($ch));
                    }
                    curl_close($ch);
                    if(strpos($output, 'Message Submitted Successfully') !== false) {
                        Session::flash('success', 'Customer has been added successfully.');
                    }
                    else {
                        Session::flash('error', 'An error occured while sending welcome message.');    
                    }
                    return Redirect('/customers');  
                }
                else {
                    Session::flash('error', 'An error occured while saving customer detail.');
                    return Redirect::back()->withInput($request->all());    
                }
            }
        }
    }

    ####### FUNCTION TO CHANGE CUSTOMER STATUS #######
    function update_customer_status(Request $request) {
        $validator = Validator::make($request->all(), [ 
            'id' => 'required|numeric',
            'status' => 'required',
        ]);  
        if($validator->fails()) 
        {          
            return response()->json([
                'success' => 'false',
                'errors'  => $validator->errors()->all(),
            ], 400); 
        }
        else 
        {
            $is_exist = Customer::where('id', $request->input('id'))->first();
            if(!empty($is_exist)) {
                $data['status'] = $request->input('status');
                if(Customer::where('id', $request->input('id'))->update($data)) {
                    die('suc');
                }
                else {
                    die('error');
                }
            }
            else {
                die('error');    
            }
        }
        die;
    }

    function get_customers(Request $request, $package_id=null, $sell_package=null) {
        if(!empty($package_id) && $sell_package != '') {
            $package_data = TourPackage::where('id', $package_id)->first();
            if(!empty($package_data)) {    
                $customers_arr = Customer::where('status', 1)->orderby('created_at', 'desc')->get();
                return View::make('customers.get_customers')->with('customers_arr', $customers_arr)->with('package_data', $package_data)->with('sell_package', $sell_package);
            }
            else {
                die('Invalid Parameter.');    
            }
        }
        else {
            die('Invalid Request');
        }
    }

    ####### FUNCTION TO IMPORT CUSTOMERS #######
    function import_customers(Request $request) {
        if (Input::hasFile('customers_data'))
        {
            if(Input::file('customers_data')->getClientOriginalExtension() == 'csv') {
                $customers_arr = array();
                $filename = Input::file('customers_data')->getRealPath();
                $customers_arr = $this->fetch_customers($filename);
                if(count($customers_arr) > 1) {
                    $destinationPath = base_path('storage\uploaded_csv_files');
                    $org_file_name = strtotime(now()).'.csv';
                    if(!File::isDirectory($destinationPath)) {
                        File::makeDirectory($destinationPath, 0777, true, true);
                    }
                    if(Input::file('customers_data')->move($destinationPath, $org_file_name)) {
                        $org_file_name = base64_encode($org_file_name);
                        return View::make('customers.import_customers')->with('customers_arr', $customers_arr)->with('org_file_name', $org_file_name);
                    }
                    else {
                        Session::flash('error', 'An error occured while fetching customers.');
                    }
                }
                else {
                    Session::flash('error', 'No field matched with data-base.');    
                }
            }
            else {
                Session::flash('error', 'Please upload only CSV file.');
            }
        }
        else {
            Session::flash('error', 'Please upload file.');
        }
        return Redirect::back();
    }

    ####### FUNCTION TO IMPORT CUSTOMERS #######
    function save_uploaded_customers(Request $request, $file_name=null) {
        if(!empty($file_name)) {
            $file_name = base64_decode($file_name);
            $file_name = storage_path().'\\uploaded_csv_files\\'.$file_name;
            $customers_arr = $this->fetch_customers($file_name);
            $result = [];
            foreach($customers_arr as $key => $customer) {
                $save_data = [];
                foreach($customers_arr['indexes'] as $index_key => $val) {
                    if(!empty($val)) {
                        $save_data[strtolower($val)] = '';    
                    }
                }
                if($key != 'indexes') {  
                    if(isset($customer['name']) && !empty($customer['name'])) {
                        $name = explode(' ', $customer['name']);
                        $save_data['first_name'] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $name[0]);
                        if(isset($name[1])) {
                            $save_data['last_name'] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $name[1]);; 
                        }
                        else {
                            $save_data['last_name'] = '';
                        }
                    }
                    else {
                        $save_data['first_name'] = 'No';
                        $save_data['last_name'] = 'Name';   
                    }   
                    if(isset($customer['email']) && !empty($customer['email'])) {
                        $save_data['email'] = $customer['email'];
                    }
                    if(isset($customer['phone']) && !empty($customer['phone'])) {
                        $save_data['phone'] = preg_replace("/\s+/", "", $customer['phone']);
                    }
                    if(isset($customer['phone2']) && !empty($customer['phone2'])) {
                        $save_data['phone2'] = preg_replace("/\s+/", "", $customer['phone2']);
                    }
                    $validator = Validator::make($save_data, [ 
                        'first_name' => 'required',
                        'email' => 'email|unique:customers',
                        'phone' => 'required|unique:customers',
                        'phone2' => 'unique:customers',
                    ]);  
                    if($validator->fails()) 
                    {   
                        $save_data['reason'] = $validator->errors()->all();        
                        $result['rejected'][] = $save_data;
                    }
                    else 
                    {
                        if(Customer::create($save_data)) {
                            $result['succeed'][] = $save_data;
                        }
                        //$result['succeed'][] = $save_data;
                    }
                }
                else {
                    $result['indexes'] = $customers_arr['indexes'];  
                }
            }
            return view::make('customers.import_customers')->with('result', $result);
        }  
        else {
            Session::flash('error', 'Invalid Parameter.');
        }  
        return Redirect('/customers');
    }

    function fetch_customers($file_name) {
        if(($file = fopen($file_name, 'r')) !== false)
        {
            $i = 0;
            $supported_fields_arr = Config::get('constants.SUPPORTED_FIELDS_ARR');
            $customers_arr = [];
            while (($row = fgetcsv($file, 1000, ',')) !== false)
            {
                if($i > 0 && !empty($customers_arr)) {
                    foreach($row as $key => $field_name) {
                        if(!empty($customers_arr['indexes'][$key])) {
                            $customers_arr[$i][strtolower($customers_arr['indexes'][$key])] = $field_name;
                        }
                    }
                }
                else {
                    foreach($row as $key => $field_name) {
                        if(in_array(strtolower($field_name), $supported_fields_arr)) {
                            $customers_arr['indexes'][] = $field_name;   
                        }
                        else {
                            $customers_arr['indexes'][] = '';
                        }
                    }
                }

                $i++;
            }
            fclose($file);
            return $customers_arr;
        }
    }

    ####### FUNCTION TO BOOK FLIGHT #######
    function book_flight(Request $request) {
        $data = $request->all();
        $validator = [ 
                        'customer_id' => 'required|numeric',
                        'ticket_number' => 'required|numeric',
                        'pnr_number' => 'required', 
                        'airways_name' => 'required',
                        'flight_type' => 'required',  
                        'departure_date' => 'required|date|after:'.date('m/d/Y', strtotime('-1 day', strtotime(date('m/d/Y')))), 
                        'flight_from' => 'required',
                        'flight_to' => 'required',
                        'price' => 'numeric',
                        'currency_type' => 'required',
                        'payment_due_date' => 'required|date|after:'.date('m/d/Y', strtotime('-1 day', strtotime(date('m/d/Y')))),
                    ];
        if($data['flight_type'] == 'round_trip') {
            $validator['arrival_date'] = 'required|date|after:'.$request->departure_date;
        }
        $validator = Validator::make($data, $validator); 
        if($validator->fails()) 
        {          
            return response()->json([
                'success' => 'false',
                'errors'  => $validator->errors()->all(),
            ], 400); 
        }
        else 
        {
            if(BookedFlight::create($data)) {
                die('suc');
            }
            else {
                die('error');
            }
        }
        die('error');
    }

    ####### FUNCTION TO GET ORGANIZATIONS TO AUTO-FILL ORGANIZATION FIELDS WHILE ADDING/UPDATING CUSTOMER DETAIL #######
    function get_organizations(Request $request) {
        $validator = Validator::make($request->all(), [ 
            'organization' => 'required',
        ]);  
        if($validator->fails()) 
        {          
            return response()->json([
                'success' => 'false',
                'errors'  => $validator->errors()->all(),
            ], 400); 
        }
        else 
        {
            $organizations_arr = Customer::select('organization','organization_location','organization_gst_number')->where('organization', 'like', '%'.$request->organization.'%')->get();
            if(count($organizations_arr) > 0) {
                $html = '';
                foreach($organizations_arr as $organization) {
                    $html = $html.'<li location="'.$organization->organization_location.'" gst_number="'.$organization->organization_gst_number.'">'.$organization->organization.'</li>';    
                }
                return $html;
            }
            die;
        }
    }
}
