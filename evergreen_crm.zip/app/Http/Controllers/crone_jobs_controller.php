<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use Storage;
class crone_jobs_controller extends Controller
{
    function send_birthday_reminder() {
        if(!Storage::disk('local')->exists('error_log.txt')) {
            Storage::put('error_log.txt', '########## CRONE JOB START-----'.date('d-m-Y h:i:s').'------#########');
        }
        else {
            Storage::append('error_log.txt', '########## CRONE JOB START-----'.date('d-m-Y h:i:s').'------#########');
            
        }
        $customers_arr = Customer::where('status', 1)->where(function($q) {
            $q->where('birthday_reminder', date("m/d/Y"))->orWhere('anniversary_reminder', date("m/d/Y"));
        })->get();   
        //echo '<pre>';print_r($customers_arr);die;
        if(count($customers_arr) > 0) {
            Storage::append('error_log.txt', count($customers_arr).' CUSTOMERS FOUND -----'.date('d-m-Y h:i:s').'------');
            foreach($customers_arr as $customer) {
                if(!empty($customer->phone)) {
                    $msg_sent = true;
                    if($customer->birthday_reminder == date('m/d/Y')) {
                        Storage::append('error_log.txt', 'CUSTOMER BIRTHDAY---ID:'.$customer->id.'----NAME:'.$customer->first_name.' '.$customer->last_name.'------PHONE:'.$customer->phone.'-----'.date('d-m-Y h:i:s').'------');
                        $msg_type = 'Birthday';
                        $msg_sent = $this->send_message($customer->id, $customer->phone, $msg_type);    
                        if($msg_sent) {
                            $birthday_reminder_for_next_year = strtotime($customer->birthday_reminder); 
                            $birthday_reminder_for_next_year = strtotime('+ 1 year', $birthday_reminder_for_next_year);
                            $birthday_reminder_for_next_year = date('m/d/Y', $birthday_reminder_for_next_year);
                            Customer::where('id', $customer->id)->update(['birthday_reminder' => $birthday_reminder_for_next_year]);
                        }
                    }
                    if($customer->anniversary_reminder == date('m/d/Y')) {
                        Storage::append('error_log.txt', 'CUSTOMER ANNIVERSARY---ID:'.$customer->id.'----NAME:'.$customer->first_name.' '.$customer->last_name.'------PHONE:'.$customer->phone.'-----'.date('d-m-Y h:i:s').'------');
                        $msg_type = 'ANNIVERSARY';
                        $msg_sent = $this->send_message($customer->id, $customer->phone, $msg_type);    
                        if($msg_sent) {
                            $anniversary_reminder_for_next_year = strtotime($customer->anniversary_reminder); 
                            $anniversary_reminder_for_next_year = strtotime('+ 1 year', $anniversary_reminder_for_next_year);
                            $anniversary_reminder_for_next_year = date('m/d/Y', $anniversary_reminder_for_next_year);
                            Customer::where('id', $customer->id)->update(['anniversary_reminder' => $anniversary_reminder_for_next_year]);
                        }
                    }   
                }
                else {
                    Storage::append('error_log.txt', 'ID:'.$customer->id.'----PHONE NUMBER NOT FOUND-----'.date('d-m-Y h:i:s').'------');    
                }     
            }
        }   
        else {
            Storage::append('error_log.txt', 'No CUSTOMER FOUND -----'.date('d-m-Y h:i:s').'------');  
        }
        Storage::append('error_log.txt', '########## CRONE JOB END-----'.date('d-m-Y h:i:s').'------#########');
        die('done.');
    }

    function send_message($customer_id, $phone, $msg_type) {
        //Your authentication key
        $authKey = "313165766572677265656e3130301579841720";
        //Multiple mobiles numbers separated by comma
        //$mobileNumber = "9779991525,6284323217";
        $mobileNumber = $phone;
        //Sender ID,While using route4 sender id should be 6 characters long.
        $senderId = "TRAVEL";
        //Your message to send, Add URL encoding here.
        if($msg_type == 'Birthday') {
            $message = 'Birthday Message';
        }
        else {
            $message = 'Anniversary Marriage';
        }
        //Define route 
        $route = "12";
        //Prepare you post parameters
        $postData = array(
            'authkey' => $authKey,
            'number' => $mobileNumber,
            'message' => $message,
            'senderid' => $senderId,
            'route' => $route,
            'username' => 'evergreen',
            'password' => 'rajiv555'
        );
        //API URL
        $url = "http://justgosms.com/http-api.php";
        // init the resource
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData
            //,CURLOPT_FOLLOWLOCATION => true
        ));
        //Ignore SSL certificate verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        //get response
        $output = curl_exec($ch);
        //Print error if any
        if (curl_errno($ch)) {
            Storage::append('error_log.txt', 'CUSTOMER '.$msg_type.'---ID:'.$customer_id.'----ERROR:'.curl_error($ch).'-----'.date('d-m-Y h:i:s').'------');
        }
        curl_close($ch);
        if(strpos($output, 'Message Submitted Successfully') !== false) {
            Storage::append('error_log.txt', 'CUSTOMER '.$msg_type.'---ID:'.$customer_id.'----'.$msg_type.' Message has been sent successfully-----'.date('d-m-Y h:i:s').'------');         
            return true;
        }
        return false;
    }
}
