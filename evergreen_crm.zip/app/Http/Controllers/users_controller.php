<?php
namespace App\Http\Controllers;
use View;
use Illuminate\Http\Request;
use App\User;
use App\TourPackage;
use App\Customer;
use App\SoldPackage;
use App\BookedFlight;
use Validator;
use Redirect;
use Auth;
use Session;
use Hash;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class users_controller extends Controller
{
    use SendsPasswordResetEmails;
    public function __construct()
    {
        $this->middleware('auth')->except('login','register','reset_password');
    }

    function login(Request $request)
    {        
        $data = $request->all();
        if(!empty($data)) 
        {
            $validator = Validator::make($request->all(), [ 
                'email' => 'required|email',
                'password' => 'required',  
            ]);  
            if($validator->fails()) 
            {          
                return Redirect::back()->withInput($request->all())->withErrors($validator);    
            }
            else 
            {
                $admin = request()->except(['_token','remember_token']);
                $super_admin = $admin;
                $remember_me = $request->has('remember_token') ? true : false;
                if(Auth::attempt($admin, $remember_me))
                {
                    return redirect('/dashboard'); 
                } 
                else {
                    Session::flash('error', 'Email or Password is incorrect.');
                    return Redirect::back()->withInput($request->all());
                }                  
            }
        }
        else if(Auth::User()) {
            return redirect('dashboard');
        }
        return View::make('users.login');
    }

    ####### TEST FUNCTION TO ADD NEW USER ######
    function register(Request $request)
    {        
        $input['first_name'] = 'Ravinder';
        $input['role'] = '0';
        $input['email'] = 'ravinderbeatumm@gmail.com';
        $input['phone'] = '5555555555';
        $input['password'] = Hash::make('beatum-2020');
        echo '<pre>';print_r($input);die;
        $user = User::create($input);
        echo '<pre>';print_r($user);die;
        return View::make('users.login');
    }   

     #######  ######
    function dashboard(Request $request)
    { 
        $recent_bookings_arr = SoldPackage::with(['customers'])->where('created_at', '>=', date('Y-m-d', strtotime('-6 days')))->orderby('created_at', 'desc')->get();
        $recent_customers_arr = Customer::where('status', 1)->where('created_at', '>=', date('Y-m-d', strtotime('-6 days')))->orderby('created_at', 'desc')->get();
        $recent_booked_flights_arr = BookedFlight::with(['customers'])->where('created_at', '>=', date('Y-m-d', strtotime('-6 days')))->orderby('created_at', 'desc')->get();
        $total_sold_packages_count = SoldPackage::count();
        $total_customer = Customer::where('status', 1)->count();
        $total_booked_flights = BookedFlight::all()->count();
        //echo '<pre>';print_r($total_booked_flights);die;
        return View::make('dashboard')->with('recent_bookings_arr', $recent_bookings_arr)->with('recent_customers_arr', $recent_customers_arr)->with('total_sold_packages_count', $total_sold_packages_count)->with('total_booked_flights', $total_booked_flights)->with('total_customer', $total_customer)->with('recent_booked_flights_arr', $recent_booked_flights_arr);
    }


    ####### FUNCTION TO CHANGE LOGGED IN USER'S PASSWORD ######
    function change_password(Request $request)
    {
        $data = $request->all();
        if(!empty($data)) 
        {
            $validator = Validator::make($request->all(), [ 
                'password' => 'required',
                'new_password' => 'required',
                'confirm_password' => 'required|same:new_password',  
            ]);  
            if($validator->fails()) 
            {          
                return Redirect::back()->withInput($request->all())->withErrors($validator);    
            }
            else 
            {
                $current_password = Auth::User()->password;     
                if(Hash::check($request['password'], $current_password))
                {           
                    $user_id = Auth::User()->id;                       
                    $obj_user = User::find($user_id);
                    $obj_user->password = Hash::make($request['new_password']);;
                    $obj_user->save(); 
                    Session::flash('success', 'Password has been changed successfully.');
                    return redirect('dashboard');
                }
                else {
                    Session::flash('error', 'Old password is incorrect.');
                    return Redirect::back();
                }
            }    
        }
        return View::make('users.change_password');
    }

    ####### FUNCTION TO EDIT/MANAGE LOGGED IN USER'S PROFILE ######
    function edit_profile(Request $request)
    {
        $data = $request->all();
        if(!empty($data)) 
        {
            $validator = Validator::make($request->all(), [ 
                'email' => 'required|email|unique:users,email,'.Auth::User()->id,
                'first_name' => 'required',
                'phone' => 'required|regex:/[0-9]{9}/',
                'phone2' => 'required|regex:/[0-9]{9}/',
                'company_name' => 'required',
                'city' => 'required',
                'country' => 'required',
            ]);  
            if($validator->fails()) 
            {          
                return Redirect::back()->withInput($request->all())->withErrors($validator);    
            }
            else 
            {
                unset($data['_method']);
                unset($data['_token']);
                User::where('id', Auth::User()->id)->update($data);
                Session::flash('success', 'User detail has been updated successfully.'); 
                return Redirect::back();
            }
        }
        return View::make('users.edit_profile', ['user_data' => Auth::User()]);
    }

    
    function reset_password() {
        return View::make('users.reset_password');
    }
}
?>
