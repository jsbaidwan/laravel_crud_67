<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use View;
use Auth;
use App\TourPackage;
use App\Customer;
use App\SoldPackage;
use App\BookedFlight;
use Session;
use Redirect;
use Validator;
use Config;
use PDF;

class packages_controller extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    ####### FUNCTION TO SHOW LIST OF PACKAGES #######
    function index(Request $request) {
        $packages_arr = TourPackage::orderby('created_at', 'desc')->get();
        //echo '<pre>';print_r($packages_arr);die;
        return View::make('packages.index')->with('packages_arr', $packages_arr);
    }

    ####### FUNCTION TO RENDER ADD/EDIT PACKAGE FORM #######
    function add_package(Request $request, $id=null) {
        $package_data = array();
        if(!empty($id)) {
            $package_data = TourPackage::where('id', $id)->first();
        }
        return View::make('packages.add_package')->with('package_data', $package_data);
    }

    ####### FUNCTION TO SAVE PACKAGE #######
    function save_package(Request $request) {
        $validator = Validator::make($request->all(), [ 
            'price' => 'required|numeric',
            'title' => 'required',
            'departure_date' => 'required|date|after:'.date('m/d/Y', strtotime('-1 day', strtotime(date('m/d/Y')))),
            'days' => 'required',  
            'nights' => 'required',
            'currency_type' => 'required' 
        ]);  
        if($validator->fails()) 
        {          
            return Redirect::back()->withInput($request->all())->withErrors($validator);    
        }
        else 
        {
            $data = $request->all();
            unset($data['_token']);
            $data['duration'] = $data['days'].' Days '.$data['nights'].' Nights';
            unset($data['days']);
            unset($data['nights']);
            if(isset($data['id']) && !empty($data['id'])) {
                if(TourPackage::where('id', $data['id'])->update($data)) {
                    Session::flash('success', 'Package has been updated successfully.');
                    return Redirect('/packages');                
                }   
                {
                    Session::flash('error', 'An error occured while saving package.');
                    return Redirect::back()->withInput($request->all());            
                }
            }
            else {
                if(isset($data['inclusion']) && !empty($data['inclusion'])) {
                    $inclusion = str_replace(array("\r", "\n", ""), '~', $data['inclusion']);
                    if(strpos($inclusion, '~~') !== false) {
                        $inclusion = explode("~~", $inclusion);
                    }
                    $data['inclusion'] = serialize($inclusion);
                }  
                if(isset($data['exclusion']) && !empty($data['exclusion'])) {
                    $exclusions = str_replace(array("\r", "\n", ""), '~', $data['exclusion']);
                    if(strpos($exclusions, '~~') !== false) {
                        $exclusions = explode("~~", $exclusions);
                    }
                    $data['exclusion'] = serialize($exclusions);
                }  
                if(TourPackage::create($data)) {
                    Session::flash('success', 'Package has been added successfully.');
                    return Redirect('/packages');    
                }
                else {
                    Session::flash('error', 'Invalid Request. Parameter Missing.');
                    return Redirect::back()->withInput($request->all());    
                }
            }
        }
    }

    ####### FUNCTION TO CHANGE PACKAGE STATUS #######
    function update_package_status(Request $request) {
        $validator = Validator::make($request->all(), [ 
            'id' => 'required|numeric',
            'status' => 'required',
        ]);  
        if($validator->fails()) 
        {          
            return response()->json([
                'success' => 'false',
                'errors'  => $validator->errors()->all(),
            ], 400); 
        }
        else 
        {
            $is_exist = TourPackage::where('id', $request->input('id'))->first();
            if(!empty($is_exist)) {
                $data['status'] = $request->input('status');
                if(TourPackage::where('id', $request->input('id'))->update($data)) {
                    die('suc');
                }
                else {
                    return response()->json([
                        'success' => 'false',
                        'errors'  => array('An error occured while updating status.'),
                    ], 400);
                }
            }
            else {
                return response()->json([
                    'success' => 'false',
                    'errors'  => array('Invalid Package.'),
                ], 400);    
            }
        }
        die;
    }

    ####### FUNCTION TO CHANGE PACKAGE STATUS #######
    function send_package(Request $request) {
        $validator = Validator::make($request->all(), [ 
            'customer_ids_arr' => 'required',
            'sms_text' => 'required',
        ]);  
        if($validator->fails()) 
        {          
            return response()->json([
                'success' => 'false',
                'errors'  => $validator->errors()->all(),
            ], 400);

        }
        else 
        {
            $customer_ids_arr = explode(',', $request->input('customer_ids_arr'));
            $customer_ids_arr = Customer::whereIn('id', $customer_ids_arr)->pluck('phone','id')->toArray(); 
            if(!empty($customer_ids_arr)) {
                $phone_numbers = implode(',', $customer_ids_arr);
                //Your authentication key
                $authKey = Config::get('constants.SMS_API_AUTH_KEY');
                //Multiple mobiles numbers separated by comma
                //$mobileNumber = "9779991525,6284323217";
                $mobileNumber = $phone_numbers;
                //Sender ID,While using route4 sender id should be 6 characters long.
                $senderId = Config::get('constants.SMS_API_SENDER_ID');
                //Your message to send, Add URL encoding here.
                $message = $request->input('sms_text');
                
                //Define route 
                $route = config::get('constants.SMS_API_ROUTE_ID');
                //Prepare you post parameters
                $postData = array(
                    'authkey' => $authKey,
                    'number' => $mobileNumber,
                    'message' => $message,
                    'senderid' => $senderId,
                    'route' => $route,
                    'username' => config::get('constants.SMS_API_USER_NAME'),
                    'password' => config::get('constants.SMS_API_PASSWORD'),
                );
                //API URL
                $url = config::get('constants.SMS_API_URL');
                // init the resource
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => $postData
                    //,CURLOPT_FOLLOWLOCATION => true
                ));
                //Ignore SSL certificate verification
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                //get response
                $output = curl_exec($ch);
                //Print error if any
                if (curl_errno($ch)) {
                    Session::flash('error', curl_error($ch));
                }
                curl_close($ch);
                if(strpos($output, 'Message Submitted Successfully') !== false) {
                    die('suc');
                }
                else {
                    die('error');
                }
            }    
        }
        die('error');
    }

    ####### FUNCTION TO SELL PACKAGE #######
    function sell_package(Request $request) {
        $validator = Validator::make($request->all(), [ 
            'package_id' => 'required|numeric',
            'customer_ids_arr' => 'required',
            'price' => 'required|numeric',
            'days' => 'required',  
            'nights' => 'required', 
            'payment_due_date' => 'required|date|after:'.date('m/d/Y', strtotime('-1 day', strtotime(date('m/d/Y')))),
        ]);  
        if($validator->fails()) 
        {          
            return response()->json([
                'success' => 'false',
                'errors'  => $validator->errors()->all(),
            ], 400); 
        }
        else 
        {
            $is_exist = TourPackage::where('id', $request->input('package_id'))->first();
            if(!empty($is_exist)) {
                $customer_ids_arr = explode(',', $request->input('customer_ids_arr'));
                $customer_ids_arr = Customer::whereIn('id', $customer_ids_arr)->pluck('phone','id')->toArray(); 
                if(!empty($customer_ids_arr)) {
                    foreach($customer_ids_arr as $customer_id => $phone) {
                        $save_data = array(
                            'package_id' => $is_exist->id,
                            'customer_id' => $customer_id,
                            'package_title' => $is_exist->title,
                            'package_duration' => $request->input('days').' Days '.$request->input('nights').' Nights',
                            'package_price' => $request->input('price'),
                            'currency_type' => $is_exist->currency_type,
                            'package_departure_date' => $is_exist->departure_date,
                            'inclusion' => $is_exist->inclusion,
                            'exclusion' => $is_exist->exclusion,
                            'payment_due_date' => $request->payment_due_date
                        );  
                        SoldPackage::create($save_data);
                    }
                    die('suc');
                }    
            }
            else {
                return response()->json([
                    'success' => 'false',
                    'errors'  => array('Invalid Package.'),
                ], 400);    
            }
        }
        die;
    }


    ####### FUNCTION TO SELL PACKAGE #######
    function sell_package_manually(Request $request) {
        $validator = Validator::make($request->all(), [ 
            'package_price' => 'required|numeric',
            'package_departure_date' => 'required|date|after:'.date('m/d/Y', strtotime('-1 day', strtotime(date('m/d/Y')))), 
            'currency_type' => 'required',
            'days' => 'required',  
            'nights' => 'required', 
            'currency_type' => 'required',
            'customer_id' => 'required|numeric',
            'payment_due_date' => 'required|date|after:'.date('m/d/Y', strtotime('-1 day', strtotime(date('m/d/Y')))),
        ]);  
        if($validator->fails()) 
        {          
            return response()->json([
                'success' => 'false',
                'errors'  => $validator->errors()->all(),
            ], 400); 
        }
        else 
        {
            $data = $request->all();
            unset($data['_token']);
            $data['package_duration'] = $data['days'].' Days '.$data['nights'].' Nights';
            unset($data['days']);
            unset($data['nights']);
            if(isset($data['inclusion']) && !empty($data['inclusion'])) {
                $inclusion = str_replace(array("\r", "\n", ""), '~', $data['inclusion']);
                if(strpos($inclusion, '~~') !== false) {
                    $inclusion = explode("~~", $inclusion);
                }
                $data['inclusion'] = serialize($inclusion);
            }  
            if(isset($data['exclusion']) && !empty($data['exclusion'])) {
                $exclusions = str_replace(array("\r", "\n", ""), '~', $data['exclusion']);
                if(strpos($exclusions, '~~') !== false) {
                    $exclusions = explode("~~", $exclusions);
                }
                $data['exclusion'] = serialize($exclusions);
            }  
            //echo '<pre>';print_r($data);die;
            if(SoldPackage::create($data)) {
                die('suc');
            }
            else {
                die('error');
            }
        }
        die('error');
    }

    ####### FUNCTION TO SHOW SOLD PACKAGES TO THE CUSTOMER #######
    function get_sold_packages_to_customer(Request $request, $customer_id=null) {
        if(!empty($customer_id)) {
            $sold_packages_arr = SoldPackage::where('customer_id', $customer_id)->orderby('created_at', 'desc')->get();
            $booked_flights_arr = BookedFlight::with(['customers'])->where('customer_id', $customer_id)->orderby('created_at', 'desc')->get();
            return view::make('packages.get_sold_packages_to_customer')->with('sold_packages_arr', $sold_packages_arr)->with('booked_flights_arr', $booked_flights_arr);
        }
        else {
            Session::flash('error', 'Invalid Request. Parameter Missing.');
            return Redirect::back();
        }
    }

    ####### FUNCTION TO DOWNLOAD INVOICE #######
    function download_invoice(Request $request, $id=null, $customer_id=null, $type=null) {
        $posted_data['id'] = $id;
        $posted_data['customer_id'] = $customer_id;
        $posted_data['type'] = $type;
        $validator = Validator::make($posted_data, [ 
            'customer_id' => 'required|numeric',
            'type' => 'required',
            'id' => 'required|numeric',
        ]);  
        if($validator->fails()) 
        {          
            return Redirect::back()->withErrors($validator);
        }
        else 
        {  
            $data = [];
            if($posted_data['type'] == 'flight') {
                $data = BookedFlight::with(['customers'])->where('id', $request->id)->where('customer_id', $request->customer_id)->first();
            }
            else if($posted_data['type'] == 'package') {
                $data = SoldPackage::with(['customers'])->where('id', $request->id)->where('customer_id', $request->customer_id)->first();
            }
            else {
                Session::flash('error', 'Invalid Parameter.');
                return Redirect('/customers');
            }
            //echo '<pre>';print_r($data);
            if(!empty($data)) {
                view()->share(['data' => $data, 'type' => $type]);
                $pdf = PDF::loadView('packages.download_invoice')->setPaper('a4', 'portrait');
                return $pdf->stream();
            }
            else {
                Session::flash('error', 'Provided data not matched with data-base.');
                return Redirect::back();
            }
        }  
    }
}
