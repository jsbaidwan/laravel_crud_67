<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookedFlight extends Model
{
    protected $fillable = [
        'currency_type','customer_id','ticket_number', 'pnr_number', 'airways_name', 'flight_type','departure_date','flight_from','flight_to','price','arrival_date','payment_due_date'
    ];
    public function customers()
    {
        return $this->hasOne('App\Customer', 'id', 'customer_id');
    }
}
