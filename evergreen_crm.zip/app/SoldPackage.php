<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SoldPackage extends Model
{
    //
    protected $fillable = ['package_id','customer_id','package_title','package_duration','package_price','currency_type','package_departure_date','inclusion','exclusion','payment_due_date'];
    public function tour_packages()
    {
        return $this->hasOne('App\TourPackage', 'id');
    }
    public function customers()
    {
        return $this->hasOne('App\Customer', 'id', 'customer_id');
    }
}
