<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBookedFlightsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('booked_flights', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('customer_id');
            $table->integer('package_id')->nullable();
            $table->string('ticket_number');
            $table->string('pnr_number');
            $table->string('airways_name');
            $table->enum('flight_type', array('one_way','round_trip'));
            $table->string('flight_from');
            $table->string('flight_to');
            $table->dateTime('departure_date');
            $table->dateTime('arrival_date')->nullable();
            $table->decimal('price', 10,2);
            $table->string('inclusion')->nullable();
            $table->string('exclusion')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('booked_flights');
    }
}
