<style type="text/css">
    .auto-complete-wrap {
        position:relative;
    }
    .auto-complete-wrap .auto-complete-inner-wrap {
        max-height:250px;
        overflow-y:scroll; 
        color:#555555;
        box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);
        position: absolute;
        top: 50px;
        width: 100%;
        background-color: #fff;
        display:none;
    }  
    .auto-complete-wrap .options-wrap li {
        margin: 0;
        padding: 5px 0 5px 20px;
        cursor: pointer;
    }    
    .auto-complete-wrap .options-wrap li:hover {
        background-color:#eaeaea;
    } 
    .auto-complete-wrap .close-auto-complete {
        text-align:right;
        margin: 0;
        padding-right:10px;
    }
    .auto-complete-wrap .close-icon {
        cursor: pointer;
    }
</style>
<?php echo Form::model($customer_data, ['route' => 'save_customer', 'id' => 'add-customer-form']); ?>

    <?php echo Form::hidden('id', null); ?>

    <div class="my-profile">
        <label>First name</label>
        <?php echo Form::text('first_name', null, ['class' => 'form-control validate[required]', 'required' => true]); ?>

        <label>Last name</label>
        <?php echo Form::text('last_name', null, ['class' => 'form-control']); ?>

        <label>Email</label>
        <?php echo Form::email('email', null, ['class' => 'form-control validate[custom[email]]', 'required' => true]); ?>

        <label>Phone</label>
        <?php echo Form::text('phone', null, ['class' => 'form-control validate[required,custom[number]]', 'required' => true]); ?>   
        <label>Date of birth</label>
        <div class="input-group date">
            <?php echo Form::text('dob', null, ['class' => 'form-control datepicker']); ?>

            <div class="input-group-addon">
                <i class="fa fa-calendar" aria-hidden="true"></i>
            </div>
        </div>
        <label>Marriage anniversary date</label>
        <div class="input-group date">
            <?php echo Form::text('marriage_anniversary', null, ['class' => 'form-control datepicker']); ?>

            <div class="input-group-addon">
                <i class="fa fa-calendar" aria-hidden="true"></i>
            </div>
        </div>      
        <label>Organization Name</label>
        <div class="auto-complete-wrap">
            <?php echo Form::text('organization', null, ['class' => 'form-control organization-name', 'autocomplete' => 'off', 'onkeyup' => 'get_organizations(this);']); ?>

            <ul class="auto-complete-inner-wrap">
                <li class="close-auto-complete"><span class="close-icon" onclick = "close_autocomplete()">x</span></li>
                <span class="options-wrap">
                </span>
            </ul>
        </div>
        <label>Organization Location/Address</label>
        <?php echo Form::text('organization_location', null, ['class' => 'form-control organization-location']); ?>

        <label>Organization GST Number</label>
        <?php echo Form::text('organization_gst_number', null, ['class' => 'form-control organization-gst-number']); ?>

    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.datepicker').datepicker({
                autoclose: true
            });
        });
    </script>
<?php echo Form::close(); ?><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/customers/add_customer.blade.php ENDPATH**/ ?>