<style type="text/css">
    .tab-content{
            padding:28px 0px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap h4{
        padding:0px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul{
        background-color: transparent;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li{
        border:none;
    }
    .nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover, .nav-tabs>li>a:hover{
        color: #fff;
        background: transparent!important;
    }
    .nav-tabs>li>a{
        color: #b5b5b5;
        background-color: transparent;
        padding: 23px 30px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li{
        background:#333333;
        padding: 0px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li.active, .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li:focus, .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li:hover, .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li:hover{
        background:#005294;
        color:#fff!important;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap h4.gray{
        background:transparent;
        border:none;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul{
        border:none;
    }
</style>
<div class="table-box" style="width:100%;">
    <div class="dashboard-list-box sold_packages_and_booked_flights_wrap">
        <h4 class="gray">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#imported">Sold Packages</a></li>
                <li><a data-toggle="tab" href="#rejected">Booked Flights</a></li>
            </ul>
        </h4>
        <div class="tab-content">
            <div id="imported" class="tab-pane fade in active">
                <div class="table-responsive">
                    <table class="basic-table booking-table table-condensed">
                        <thead>
                            <tr>
                                <th>Package Name</th>
                                <th>Package Duration</th>
                                <th>Package Price</th>
                                <th>Departure Date</th>
                                <th>Sold Date</th>
                                <th>Inclusion/Exclusion</th>
                                <th>Actions</th> 
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($sold_packages_arr) > 0): ?>
                                <?php $__currentLoopData = $sold_packages_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sold_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sold_package->package_title); ?></td>
                                        <td><?php echo e($sold_package->package_duration); ?></td>
                                        <td>
                                            <?php echo Config::get('constants.CURRENCY_TYPE.'.$sold_package->currency_type);echo number_format($sold_package->package_price); ?>
                                        </td>
                                        <td><?php echo e(@date('j M, Y', @strtotime($sold_package->package_departure_date))); ?></td>
                                        <td><?php echo e(@date('j M, Y', @strtotime($sold_package->created_at))); ?></td>
                                        <td>
                                            <?php 
                                                $inclusion_arr = array();
                                                $exclusion_arr = array();
                                                if(!empty($sold_package->inclusion)) {
                                                    $inclusion_arr = unserialize($sold_package->inclusion);
                                                    if(!is_array($inclusion_arr)) {
                                                        $inclusion_arr = array($inclusion_arr);    
                                                    }
                                                }
                                                if(!empty($sold_package->exclusion)) {
                                                    $exclusion_arr = unserialize($sold_package->exclusion);
                                                    if(!is_array($exclusion_arr)) {
                                                        $exclusion_arr = array($exclusion_arr);    
                                                    }
                                                }
                                            ?>
                                            <a style="background-color:#468c21;" data-toggle="tooltip" data-placement="top" data-html="true" title="<?php if(!empty($inclusion_arr)): ?><?php $__currentLoopData = $inclusion_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inclusion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($inclusion); ?> <br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>" href="javascript:;" class="button gray"><i class="fa fa-check"></i></a>
                                            <a style="background-color:#d60d45;" data-toggle="tooltip" data-placement="top" data-html="true" title="<?php if(!empty($exclusion_arr)): ?><?php $__currentLoopData = $exclusion_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exclusion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($exclusion); ?> <br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>" href="javascript:;" class="button gray"><i class="fa fa-close" aria-hidden="true"></i></a>
                                        </td>
                                        <td>
                                            <a style="" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="<?php echo e(url('/download_invoice')); ?>/<?php echo e($sold_package->id); ?>/<?php echo e($sold_package->customer_id); ?>/package" class="button gray enabled" data-original-title="Download Invoice"><i class="fa fa-download"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                                <td colspan="6" class="no-data-found">No Package has been sold yet.</td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="rejected" class="tab-pane fade">
                <div class="dashboard-list-box sold_packages_and_booked_flights_wrap">
                    <div class="table-responsive">
                        <table class="basic-table booking-table table-condensed">
                            <thead>
                                <tr>
                                    <th>Ticket No.</th> 
                                    <th>PNR No.</th>   
                                    <th>Airways</th>
                                    <th>Price</th>   
                                    <th>Flight Details</th> 
                                    <th>Actions</th>         
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($booked_flights_arr) > 0): ?>                
                                    <?php $__currentLoopData = $booked_flights_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booked_flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($booked_flight->ticket_number); ?></td>
                                            <td><?php echo e($booked_flight->pnr_number); ?></td>
                                            <td><?php echo e($booked_flight->airways_name); ?></td>
                                            <td><?php echo Config::get('constants.CURRENCY_TYPE.'.$booked_flight->currency_type);echo number_format($booked_flight->price); ?></td>
                                            <td>
                                                <div>
                                                    <?php echo e($booked_flight->flight_from); ?> <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> <?php echo e($booked_flight->flight_to); ?> (<?php echo e(date('d, M Y', @strtotime($booked_flight->departure_date))); ?>)
                                                </div>
                                                <?php if($booked_flight->flight_type == 'round_trip'): ?>
                                                    <div>
                                                        <?php echo e($booked_flight->flight_to); ?> <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> <?php echo e($booked_flight->flight_from); ?> (<?php echo e(date('d, M Y', @strtotime($booked_flight->arrival_date))); ?>)
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a style="" data-toggle="tooltip" target="_blank" data-placement="top" title="" href="<?php echo e(url('/download_invoice')); ?>/<?php echo e($booked_flight->id); ?>/<?php echo e($booked_flight->customer_id); ?>/flight" class="button gray enabled" data-original-title="Download Invoice"><i class="fa fa-download"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                <?php else: ?> 
                                    <td colspan="7" class="no-data-found">No Flight has been booked yet.</td>
                                <?php endif; ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
        </div>
    </div>
</div>
<script trype="text/javascript">
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/packages/get_sold_packages_to_customer.blade.php ENDPATH**/ ?>