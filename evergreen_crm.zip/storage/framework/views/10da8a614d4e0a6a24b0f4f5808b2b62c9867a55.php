<!DOCTYPE html>
<html>

<head>
    <title>Evergreen-<?php echo $__env->yieldContent('title'); ?></title>
    <!--== META TAGS ==-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--== FAV ICON ==-->
    <link rel="shortcut icon" href="<?php echo e(asset('images/fav.ico')); ?>">

    <!--== ALL CSS FILES ==-->
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/plugin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/dashboard.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/css/icons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/css/validationEngine.jquery.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap-datepicker3.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('public/css/dataTables.bootstrap.min.css')); ?>" />

    <!--======== SCRIPT FILES =========-->
    <script src="<?php echo e(asset('public/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/preloader.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/dashboard-custom.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jpanelmenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.validationEngine-en.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.validationEngine.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jdataTables.bootstrap.min.js')); ?>"></script>
</head>
<?php
    $wrap_class = '';
    if(Auth::check()) {
        $wrap_class = 'sb2';
    }
?>
<body> 
    <style type="text/css">
        .alert_msgs {
            max-width: 100%;
            margin: 0 auto;
            position: fixed;
            top: 30px;
            transform: translate(-50%, -20%);
            left: 50%;
            width: 400px;
            text-align: center;
            z-index: 9999999;
        }
        .js-alert-msgs {
            display:none;
        }
        .modal{
            z-index:99999;
        }
        .no-data-found {
            text-align: center;
            font-size: 20px;
            padding: 40px 0 10px 0;
        }
        .t-box {
            cursor:pointer;
        }
        .datepicker-days .table-condensed {
            width:100%;
        }
    </style>
    <script type="text/javascript">
        function hide_alerts() {
            setTimeout(function() {
                $('.alert_msgs').fadeOut('slow')
            }, 3000);
        }
        function alert_msg (text,type) {
            $('.js-alert-msgs').show();
            $('.js-alert-msgs').text(text);
            if(type == 'success') {
                $('.js-alert-msgs').addClass('alert-success');
                $('.js-alert-msgs').removeClass('alert-danger');
            }
            else {
                $('.js-alert-msgs').addClass('alert-danger');
                $('.js-alert-msgs').removeClass('alert-success');
            }
            hide_alerts();
        }      
    </script>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert_msgs">
                <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <script type="text/javascript">
            hide_alerts();
        </script>
    <?php endif; ?>
    <?php if(Session::has('success') || Session::has('error')): ?>
        <?php
            $alert_class = '';
            $alert_msg = '';
            if(Session::has('success')) {
                $alert_class = 'alert-success';
                $alert_msg = Session::get('success');
            }
            else {
                $alert_class = 'alert-danger';
                $alert_msg = Session::get('error');
            }
        ?>
        <div class="alert <?php echo e($alert_class); ?> alert_msgs">
            <?php echo e($alert_msg); ?>

        </div>
        <script type="text/javascript">
            hide_alerts();
        </script>
    <?php endif; ?>  
    <div class="alert alert_msgs js-alert-msgs">
    </div>
    <div id="preloader">
        <div id="status"></div>
    </div>
    <div id="container-wrapper">
        <div id="dashboard">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>

</html><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/layouts/popup.blade.php ENDPATH**/ ?>