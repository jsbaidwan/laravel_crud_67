<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<style>
.not-found {
    color:#000;
    font-size:18px;
}
</style>
<div class="dashboard-content">
    <div class="row">

        <!-- Item -->
        <div class="col-lg-4 col-md-6 col-xs-6">
            <div class="dashboard-stat color-1">
                <div class="dashboard-stat-content">
                    <h4><?php echo e($total_sold_packages_count); ?></h4> <span>Sold Packages</span>
                </div>
                <div class="dashboard-stat-icon"><i class="im im-icon-Line-Chart"></i></div>
                <div class="dashboard-stat-item">
                    <p>Total No. of sold packages</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-xs-6">
            <div class="dashboard-stat color-3">
                <div class="dashboard-stat-content">
                    <h4><?php echo e($total_booked_flights); ?></h4> <span>Booked Flights</span>
                </div>
                <div class="dashboard-stat-icon"><i class="fa fa-plane"></i></div>
                <div class="dashboard-stat-item">
                    <p>Total No. of booked flights.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-xs-6">
            <div class="dashboard-stat color-4">
                <div class="dashboard-stat-content">
                    <h4><?php echo e($total_customer); ?></h4> <span>Total Customers</span>
                </div>
                <div class="dashboard-stat-icon"><i class="im im-icon-Add-UserStar"></i></div>
                <div class="dashboard-stat-item">
                    <p>Total active customers.</p>
                </div>
            </div>
        </div>


    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12 traffic">
            <div class="dashboard-list-box">
                <h4 class="gray">Recent Sold Packages</h4>
                <div class="table-box">
                    <table class="basic-table">
                        <thead>
                            <tr>
                                <th>Package Name</th>
                                <th>Customer Name</th>
                                <th>Customer Phone</th>
                                <th>Price</th>
                                <th>Duration</th>
                                <!-- <th>Purchaged Date</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($recent_bookings_arr) > 0): ?>
                                <?php $__currentLoopData = $recent_bookings_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        <td><?php echo e($recent_booking->package_title); ?></td>
                                        <td><?php echo e($recent_booking->customers['first_name']); ?> <?php echo e($recent_booking->customers['last_name']); ?></td>
                                        <td><?php echo e($recent_booking->customers['phone']); ?></td>
                                        <td>
                                            <?php echo Config::get('constants.CURRENCY_TYPE.'.$recent_booking->currency_type);echo number_format($recent_booking->package_price); ?>
                                        </td>
                                        <td><?php echo e($recent_booking->package_duration); ?></td>
                                        <!-- <td><?php echo e(@date('j M, Y', @strtotime($recent_booking->created_at))); ?></td> -->
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center not-found">No package sold recently.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12 traffic">
            <div class="dashboard-list-box">
                <h4 class="gray">Recent Booked Flights</h4>
                <div class="table-box">
                    <table class="basic-table">
                        <thead>
                            <tr>
                            <th>Ticket No.</th> 
                            <th>Customer Name</th>
                            <th>Customer Phone</th>
                            <th>PNR No.</th>   
                            <th>Airways</th>
                            <th>Price</th>   
                            <th>Flight Details</th> 
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($recent_booked_flights_arr) > 0): ?>
                                <?php $__currentLoopData = $recent_booked_flights_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booked_flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <td><?php echo e($booked_flight->ticket_number); ?></td>
                                    <td><?php echo e($booked_flight->customers['first_name']); ?> <?php echo e($booked_flight->customers['last_name']); ?></td>
                                    <td><?php echo e($booked_flight->customers['phone']); ?></td>
                                    <td><?php echo e($booked_flight->pnr_number); ?></td>
                                    <td><?php echo e($booked_flight->airways_name); ?></td>
                                    <td>
                                        <?php echo Config::get('constants.CURRENCY_TYPE.'.$booked_flight->currency_type);echo number_format($booked_flight->price); ?>
                                    </td>
                                    <td>
                                        <div>
                                            <?php echo e($booked_flight->flight_from); ?> <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> <?php echo e($booked_flight->flight_to); ?> (<?php echo e(date('d, M Y', @strtotime($booked_flight->departure_date))); ?>)
                                        </div>
                                        <?php if($booked_flight->flight_type == 'round_trip'): ?>
                                            <div>
                                                <?php echo e($booked_flight->flight_to); ?> <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> <?php echo e($booked_flight->flight_from); ?> (<?php echo e(date('d, M Y', @strtotime($booked_flight->arrival_date))); ?>)
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center not-found">No flight booked recently.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12 traffic">
            <div class="dashboard-list-box">
                <h4 class="gray">Recent Customers</h4>
                <div class="table-box">
                    <table class="basic-table">
                        <thead>
                            <tr>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Registration Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($recent_customers_arr) > 0): ?>
                                <?php $__currentLoopData = $recent_customers_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        <td><?php echo e($recent_customer->first_name); ?> <?php echo e($recent_customer->last_name); ?></td>
                                        <td><?php echo e($recent_customer->email); ?></td>
                                        <td><?php echo e($recent_customer->phone); ?></td>
                                        <td><?php echo e(@date('j M, Y', @strtotime($recent_customer->created_at))); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center not-found">No customer added recently.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/dashboard.blade.php ENDPATH**/ ?>