<?php 
    //echo Request::path();die;
    $meanu_arr = array(
        'Dashboard' => array(
            'url' => url('/dashboard'),
            'icon' => 'fa fa-tachometer',
            'sub_menus' => array('dashboard'),
        ),
        'Packages' => array(
            'url' => url('/packages'),
            'icon' => 'fa fa-plane',
            'sub_menus' => array('packages', 'manage_package'),
        ),
        'Customers' => array(
            'url' => url('/customers'),
            'icon' => 'fa fa-users',
            'sub_menus' => array('customers', 'manage_user', 'import_customers','save_uploaded_customers'),
        ),
    );
?>
<div class="dashboard-nav">
    <div class="dashboard-nav-inner">
        <ul>
            <?php $__currentLoopData = $meanu_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_name => $sub_menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $current_page = Request::path();
                    if(strpos(Request::path(), '/') !== false) {
                        $current_page = explode('/', Request::path());
                        $current_page = $current_page[0];
                    } 
                    $class = '';
                    if(in_array($current_page, $sub_menus['sub_menus'])) {
                        $class = 'active';
                    }
                ?>
                <li class="<?php echo e($class); ?>"><a href="<?php echo e($sub_menus['url']); ?>"><i class="<?php echo e($sub_menus['icon']); ?>"></i> <?php echo e($menu_name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<!-- <div class="sb2-1">
    <div class="sb2-12">
        <ul>
            <li><img src="<?php echo e(asset('public/images/placeholder.jpg')); ?>" alt="">
            </li>
            <li>
                <h5><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></h5>
            </li>
            <li></li>
        </ul>
    </div>
    <div class="sb2-13">
        <ul class="collapsible" data-collapsible="accordion">
            <?php $__currentLoopData = $meanu_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_name => $sub_menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $class = '';
                    if(in_array(Request::path(), $sub_menus['sub_menus'])) {
                        $class = 'menu-active';
                    }
                ?>
                <li>
                    <a href="<?php echo e($sub_menus['url']); ?>" class="<?php echo e($class); ?>"><i class="fa <?php echo e($sub_menus['icon']); ?>" aria-hidden="true"></i><?php echo e($menu_name); ?></a>
                </li>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div> --><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/includes/side_nav.blade.php ENDPATH**/ ?>