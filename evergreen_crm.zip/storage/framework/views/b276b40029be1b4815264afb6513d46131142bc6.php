<div class="copyrights">
    <p>2020 <i class="fa fa-copyright" aria-hidden="true"></i> Evergreen Travels by <a href="https://www.beatumit.com/" target="_blank">Beatum IT Solutions Pvt Ltd</a></p>
</div>
<div id="back-to-top">
        <a href="#"></a>
</div><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/includes/footer.blade.php ENDPATH**/ ?>