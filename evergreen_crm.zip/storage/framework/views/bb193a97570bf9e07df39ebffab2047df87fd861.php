<?php 
if(!empty($package_data)) {
    preg_match_all('!\d+!', $package_data->duration, $duration);
    $package_data->days = $duration[0][0];
    $package_data->nights = $duration[0][1];
}
?>
<?php echo Form::model($package_data, ['route' => 'save_package', 'id' => 'add-package-form']); ?>

    <?php echo Form::hidden('id', null); ?>

    <div class="my-profile">
        <label>Title</label>
        <?php echo Form::text('title', null, ['class' => 'form-control validate[required]', 'required' => true]); ?>

        <!-- <label>Tour Location</label>
        <?php echo Form::text('location', null, ['class' => 'form-control validate[required]', 'required' => true]); ?> -->
        <label>Duration</label>
        <div class="row">
            <div class="col-md-6" style="columns:2">
                <?php echo Form::text('days', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]]', 'required' => true]); ?>

                <p>Days</p>
            </div>
            <div class="col-md-6" style="columns:2">
                <?php echo Form::text('nights', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]]', 'required' => true]); ?>

                <p>Nights</p>
            </div>
        </div>
        <label>Departure date</label>
        <div class="input-group date">
            <?php echo Form::text('departure_date', null, ['class' => 'form-control validate[required] datepicker']); ?>

            <div class="input-group-addon">
                <i class="fa fa-calendar" aria-hidden="true"></i>
            </div>
        </div>  
        <label>Price</label>
        <?php echo Form::text('price', null, ['class' => 'form-control validate[required]', 'required' => true]); ?>

        <label>Select Currency</label>
        <?php echo Form::select('currency_type', Config::get('constants.CURRENCY_TYPE_LIST'), null, ['class' => 'browser-default custom-select form-control validate[required]', 'required' => true]); ?>

        <?php if(empty($package_data)): ?> 
            <label>Inclusion (Add multiple enteries by pressing enter key.)</label>
            <?php echo Form::textarea('inclusion', null, ['class' => 'form-control text-area-field', 'rows' => '3']); ?>

            <label>Exclusion (Add multiple enteries by pressing enter key.)</label>
            <?php echo Form::textarea('exclusion', null, ['class' => 'form-control text-area-field', 'rows' => '3']); ?>

        <?php endif; ?>            
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.datepicker').datepicker({
                autoclose: true
            });
        });
    </script>
<?php echo Form::close(); ?><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/packages/add_package.blade.php ENDPATH**/ ?>