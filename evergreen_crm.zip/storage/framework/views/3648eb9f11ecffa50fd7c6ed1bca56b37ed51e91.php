<?php $__env->startSection('title', 'Packages'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    .packages-list .btn-red {
        padding: 3px 8px;
        font-weight: normal;
        font-size: 13px;
    }
    .my-profile textarea {
        height:auto !important;
    }
    #packages-index-page .opacity {
        opacity:0.5;
    }
    table.basic-table th {
        background-color: #303030;
    }
    table.basic-table th, table.basic-table td {
        padding:20px 10px;
    }
</style>
<div class="dashboard-content packages-list">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12">
            <div class="dashboard-list-box">
                <h4 class="gray">All Packages
                    <button class="btn-blue btn-red pull-right" onclick="manage_package('');">+ Add Package</button>
                </h4>
                <div class="table-box">
                    <?php if(count($packages_arr) > 0): ?>
                        <table class="basic-table booking-table" id="packages-index-page">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Destination</th>
                                    <th>Duration</th>
                                    <th>Price</th>
                                    <th>Status</th>
                                    <th>Inclusion/Exclusion</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $packages_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="package_id_<?php echo e($package->id); ?>">
                                        <td><?php echo e($package->title); ?></td>
                                        <td><?php echo e($package->location); ?></td>
                                        <td><?php echo e($package->duration); ?></td>
                                        <td>
                                            <?php echo Config::get('constants.CURRENCY_TYPE.'.$package->currency_type);echo number_format($package->price); ?>
                                        </td>
                                        <?php if($package->status): ?>
                                            <td><span data-toggle="tooltip" data-placement="top" title="Change Status" class="paid t-box" status="0" onclick="change_status('<?php echo e($package->id); ?>', this);">Active</span></td>
                                        <?php else: ?>
                                            <td><span data-toggle="tooltip" data-placement="top" title="Change Status" class="cancel t-box" status="1" onclick="change_status('<?php echo e($package->id); ?>', this);">Inactive</span></td>
                                        <?php endif; ?>
                                        <td>
                                            <?php 
                                                $inclusion_arr = array();
                                                $exclusion_arr = array();
                                                if(!empty($package->inclusion)) {
                                                    $inclusion_arr = unserialize($package->inclusion);
                                                    if(!is_array($inclusion_arr)) {
                                                        $inclusion_arr = array($inclusion_arr);    
                                                    }
                                                }
                                                if(!empty($package->exclusion)) {
                                                    $exclusion_arr = unserialize($package->exclusion);
                                                    if(!is_array($exclusion_arr)) {
                                                        $exclusion_arr = array($exclusion_arr);    
                                                    }
                                                }
                                            ?>
                                            <a style="background-color:#468c21;" data-toggle="tooltip" data-placement="top" data-html="true" title="<?php if(!empty($inclusion_arr)): ?><?php $__currentLoopData = $inclusion_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inclusion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($inclusion); ?> <br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>" href="javascript:;" class="button gray"><i class="fa fa-check"></i></a>
                                            <a style="background-color:#d60d45;" data-toggle="tooltip" data-placement="top" data-html="true" title="<?php if(!empty($exclusion_arr)): ?><?php $__currentLoopData = $exclusion_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exclusion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($exclusion); ?> <br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>" href="javascript:;" class="button gray"><i class="fa fa-close" aria-hidden="true"></i></a>
                                        </td>
                                        <td>
                                            <?php
                                            $enabled = 'display:none;';
                                            $disabled = '';
                                            if($package->status) {
                                                $disabled = 'display:none;';
                                                $enabled = '';
                                            }
                                            ?>
                                            <div class="enabled" style="<?php echo e($enabled); ?>">
                                                <a data-toggle="tooltip" data-placement="top" title="Edit Package" href="javascript:;" class="button gray" onclick="manage_package('<?php echo e($package->id); ?>');"><i class="sl sl-icon-pencil"></i></a>
                                                <a data-toggle="tooltip" data-placement="top" title="Send Package" href="javascript:;" class="button gray" onclick="get_customers('<?php echo e($package->id); ?>',0);"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                                <a data-toggle="tooltip" data-placement="top" title="Sell Package" href="javascript:;" class="button gray" onclick="get_customers('<?php echo e($package->id); ?>',1);"><i class="fa fa-plane" aria-hidden="true"></i></a>    
                                            </div>
                                            <div class="disabled" style="<?php echo e($disabled); ?>">
                                                <a data-toggle="tooltip" data-placement="top" title="Edit Package" href="javascript:;" class="button gray opacity"><i class="sl sl-icon-pencil"></i></a>
                                                <a data-toggle="tooltip" data-placement="top" title="Send Package" href="javascript:;" class="button gray opacity"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                                <a data-toggle="tooltip" data-placement="top" title="Sell Package" href="javascript:;" class="button gray opacity"><i class="fa fa-plane" aria-hidden="true"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?> 
                        <div class="no-data-found">No package added yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $( document ).ready(function() {
        $('#packages-index-page').DataTable( {
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "aaSorting": []
        });
    });
    function manage_package(id) {

        $("#add_package").modal('show');
        var url = "<?php echo e(url('/add_package')); ?>";
        if(id == '') {
            $('#add_package .modal-title').text('Add Package');
            $('#add_package .submit-btn').text('Add');        
        }
        else {
            $('#add_package .modal-title').text('Update Package Detail');
            $('#add_package .submit-btn').text('Update');
            var url = "<?php echo e(url('/add_package')); ?>/"+id;     
        }
        $("#add_package .modal-body").load(url);
    }
    function save_package() {
        if(jQuery("#add-package-form").validationEngine('validate')) {
            $('#add-package-form').submit();
        }
    }

    function change_status(id,thiss) {
        var status = $(thiss).attr('status');
        if(id != '' && status != '') {
            if(confirm('Are you sure to change to status of Package?')) {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(url('/update_package_status')); ?>",
                    data: {
                        _token:'<?php echo e(csrf_token()); ?>',
                        status: status,
                        id: id,
                    },
                    success: function(data) 
                    { 
                        if(data == 'suc') {
                            if(status == 1) {
                                $(thiss).text('Active');
                                $(thiss).removeClass('cancel');
                                $(thiss).addClass('paid');
                                $(thiss).attr('status', 0);
                                $('.package_id_'+id+' .enabled').css('display', 'block');
                                $('.package_id_'+id+' .disabled').css('display', 'none');
                            }
                            else {
                                $(thiss).removeClass('paid');
                                $(thiss).addClass('cancel');
                                $(thiss).text('Inactive');
                                $(thiss).attr('status', 1);

                                $('.package_id_'+id+' .disabled').css('display', 'block');
                                $('.package_id_'+id+' .enabled').css('display', 'none');
                            }
                            alert_msg('Package status has been updated successfully.', 'success');
                        }
                        else {
                            alert_msg('An error occured while updating status.', 'error');
                        }
                    },
                    error: function(data){
                        var errors = data.responseJSON;
                        $.each(errors.errors, function( key, value ) {
                            alert_msg(value, 'error');
                        });
                    }
                });
            } 
        }
        else {
            alert_msg('Invalid Request.', 'error');
        }
    }

    function get_customers(id,sell_package) {
        if(id != '' && (sell_package == 0 || sell_package == 1)) {
            if(sell_package) {
                $('#send_package .modal-title').text('Sell Package');  
                $('.sell-package-btn').show();
                $('.send-package-btn').hide();          
            }
            else {
                $('.sell-package-btn').hide();
                $('.send-package-btn').show();
            }
            $('#send_package').modal('show');
            var url = '<?php echo e(url("/get_customers")); ?>/'+id+'/'+sell_package;
            $("#send_package .modal-body").load(url);
        }
        else {
            alert_msg('Invalid Request.', 'error');    
        }
    }
</script>

<!-- POP-UP TO MANAGE PACKAGE -->

<div id="add_package" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Update Package Detail</h4>
            </div>
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="submit" onclick="save_package();" class="btn btn-danger submit-btn">Update</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- POP-UP TO SEND PACKAGE -->
<div id="send_package" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Select Customers To Send Package Details</h4>
            </div>
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger sell-package-btn" onclick="manage_price_before_sell_package();">Sell Package</button>
                <button class="btn btn-danger send-package-btn" onclick="manage_sms_text();">Send Package</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL TO MANAGE PRICE OF PACKAGE BEFORE SELL -->
<div class="modal fade" id="manage-price-before-sell" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Manage Package</h4>
            </div>
            <?php echo Form::open(['route' => 'sell_package', 'id' => 'manage-price-before-sell-form']); ?>

                <div class="modal-body">
                    <label>Price(<span class="currency_type"></span>)</label>
                    <?php echo Form::text('price', null, ['class' => 'form-control validate[required] price', 'required' => true]); ?>

                    <label>Payment Due date</label>
                    <div class="input-group date">
                        <?php echo Form::text('payment_due_date', null, ['class' => 'form-control validate[required] payment-due-date datepicker']); ?>

                        <div class="input-group-addon">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                        </div>
                    </div> 
                    <label>Duration</label>
                    <div class="row">
                        <div class="col-md-6" style="columns:2">
                            <?php echo Form::text('days', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]] days', 'required' => true]); ?>

                            <p>Days</p>
                        </div>
                        <div class="col-md-6" style="columns:2">
                            <?php echo Form::text('nights', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]] nights', 'required' => true]); ?>

                            <p>Nights</p>
                        </div>
                    </div>
                    <?php echo Form::hidden('customer_ids_arr',null, ['class' => 'form-control customer_ids_field']); ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" onclick="sell_package();">Sell</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<!-- MODAL TO MANAGE PACKAGE/SMS TEXT -->
<div class="modal fade" id="manage-sms-text" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Manage SMS Text(Package Detail)</h4>
            </div>
            <?php echo Form::open(['route' => 'send_package', 'id' => 'manage-sms-text-form']); ?>

                <div class="modal-body">
                    <?php echo Form::textarea('sms_text',null, ['class' => 'form-control sms-text validate[required]', 'rows' => '5', 'onkeyup' => 'char_count(this);']); ?>

                    <?php echo Form::hidden('customer_ids_arr',null, ['class' => 'form-control customer_ids_field']); ?>

                    <div class="char-count-wrap"><span class="char-count">0</span> Characters Remaininig of, <span class="sms-count">0</span> SMS</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" onclick="send_package();">Send</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/packages/index.blade.php ENDPATH**/ ?>