<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    .login-form-wrap {
        background-image: url('http://getwallpapers.com/wallpaper/full/6/c/2/1257589-hd-aviation-wallpapers-1920x1080-1920x1080-download-free.jpg') !important;
        width: 100%;
        position: relative;
        z-index: 1;
        background-position: center 100% !important;
        max-height: 100%;
        padding: 80px 0 67px;
    }
    
    .login-form-wrap::before {
        content: "";
        display: block;
        position: absolute;
        z-index: -1;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: rgba(0,0,0,.65);
    }
    .login-form-wrap .form-title h2{
        color:#fff;
    }
    .login-form-wrap  .form-title h2::after, .form-title h3::after {
        background:#fff;
    }
    .login-form-wrap label, .login-form-wrap .forgotpw, .login-form-wrap .checkbox-outer {
        color:#fff;
    }
</style>
<section class="login login-form-wrap">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="login-form">
                    <?php echo Form::open(['route' => 'login', 'id' => 'login-form']); ?>

                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-title">
                                    <h2>Login</h2>
                                </div>
                            </div>
                            <div class="form-group col-xs-12">
                                <label>Email</label>
                                <?php echo Form::email('email', '', ['placeholder' => 'Enter Your Email', 'class' => 'form-control validate[required,custom[email]]']); ?>

                            </div>
                            <div class="form-group col-xs-12">
                                <label>Password</label>
                                <?php echo Form::password('password', ['class' => 'form-control validate[required]', 'placeholder' => 'Enter Your Password']); ?>

                            </div>
                            <div class="col-xs-12">
                                <div class="checkbox checkbox-danger">
                                    <?php echo e(Form::checkbox('remember_token','','', ['id' => 'checkbox6'])); ?>

                                    <label for="checkbox6">Remember Me?</label>
                                </div>
                            </div>
                            
                            <div class="col-xs-12">
                                <div class="comment-btn">
                                    <button type="submit" class="btn-blue btn-red">Login</button>
                                </div>
                            </div>
                            <div class="col-xs-12">
                                <div class="login-accounts">
                                    <a href="<?php echo e(url('/reset_password')); ?>" class="forgotpw">Forgot Password?</a>
                                </div>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery("#login-form").validationEngine();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/users/login.blade.php ENDPATH**/ ?>