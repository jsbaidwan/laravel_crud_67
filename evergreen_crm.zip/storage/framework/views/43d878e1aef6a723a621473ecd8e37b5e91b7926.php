<?php $__env->startSection('title', 'Import Customers'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    .customers-list .btn-red {
        padding: 3px 8px;
        font-weight: normal;
        font-size: 13px;
    }
    .tab-content{
        padding:28px 0px;
    }
    .dashboard-list-box.imported-customers-list-wrap h4{
        padding:0px;
    }
    .dashboard-list-box.imported-customers-list-wrap ul{
        background-color: transparent;
    }
    .dashboard-list-box.imported-customers-list-wrap ul li{
        border:none;
    }
    .nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover, .nav-tabs>li>a:hover{
        color: #fff;
        background: transparent!important;
    }
    .nav-tabs>li>a{
        color: #b5b5b5;
        background-color: transparent;
        padding: 23px 30px;
    }
    .dashboard-list-box.imported-customers-list-wrap ul li{
        background:#333333;
        padding: 0px;
    }
    .dashboard-list-box.imported-customers-list-wrap ul li.active, .dashboard-list-box ul li:focus, .dashboard-list-box ul li:hover, .dashboard-list-box ul li:hover{
        background:#005294;
        color:#fff!important;
    }
    .dashboard-list-box.imported-customers-list-wrap h4.gray{
        background:transparent;
        border:none;
    }
    .dashboard-list-box.imported-customers-list-wrap ul{
        border:none;
    }
</style>
<div class="dashboard-content customers-list">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12">
            <?php if(isset($result) && !empty($result)): ?>
                <div class="dashboard-list-box imported-customers-list-wrap">
                    <h4 class="gray">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#imported">Imported Customers(<?php echo e(@count($result['succeed'])); ?>)</a></li>
                            <li><a data-toggle="tab" href="#rejected">Rejected Customers(<?php echo e(@count($result['rejected'])); ?>)</a></li>
                    
                        </ul>
                    </h4>
                    <div class="tab-content">
                        <div id="imported" class="tab-pane fade in active">
                            <div class="table-responsive">
                                <?php if(isset($result['succeed']) && count($result['succeed']) > 0): ?>
                                    <table class="basic-table booking-table table-condensed" id="customers-index-page">
                                        <thead>
                                            <tr>
                                                <?php if(!empty($result['indexes'])): ?>
                                                    <?php $__currentLoopData = $result['indexes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(!empty($index)): ?>
                                                            <th><?php echo e($index); ?></th>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $result['succeed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['first_name'])); ?> <?php echo e(@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['last_name'])); ?></td>
                                                    <?php if(!empty($result['indexes'])): ?>
                                                        <?php $__currentLoopData = $result['indexes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(!empty($index) && $index != 'Name'): ?>
                                                                <td><?php echo e($customer[strtolower($index)]); ?></td>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        </tbody>
                                    </table>
                                <?php else: ?> 
                                    <div class="no-data-found">No Customer imported.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div id="rejected" class="tab-pane fade">
                            <div class="dashboard-list-box">
                                <div class="table-responsive">
                                    <?php if(isset($result['rejected']) && count($result['rejected']) > 0): ?>
                                        <table class="basic-table booking-table table-condensed" id="customers-index-page">
                                            <thead>
                                                <tr>
                                                    <?php if(!empty($result['indexes'])): ?>
                                                        <?php $__currentLoopData = $result['indexes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(!empty($index)): ?>
                                                                <th><?php echo e($index); ?></th>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <th>Reason</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $result['rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e(@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['first_name'])); ?> <?php echo e(@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['last_name'])); ?></td>
                                                        <?php if(!empty($result['indexes'])): ?>
                                                            <?php $__currentLoopData = $result['indexes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(!empty($index) && $index != 'Name'): ?>
                                                                    <td><?php echo e($customer[strtolower($index)]); ?></td>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>  
                                                        <td>
                                                            <?php $__currentLoopData = $customer['reason']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div style="color:red;"><?php echo e($reason); ?></div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                            </tbody>
                                        </table>
                                    <?php else: ?> 
                                        <div class="no-data-found">All customers imported successfully.</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="dashboard-list-box">
                    <h4 class="gray">Import Customers(<?php echo e(@count($customers_arr)-1); ?>)
                        <a style="margin-left:10px;" href="<?php echo e(url('/customers')); ?>" class="btn-blue btn-red pull-right">Cancel</a>
                        <a onclick="save_customers();" href="<?php echo e(url('/save_uploaded_customers')); ?>/<?php echo e($org_file_name); ?>" class="btn-blue btn-red pull-right">Save Customers</a>
                    </h4>
                    <div class="table-responsive">
                        <?php if(count($customers_arr) > 1): ?>
                            <table class="basic-table booking-table table-condensed" id="customers-index-page">
                                <thead>
                                    <tr>
                                        <?php if(!empty($customers_arr['indexes'])): ?>
                                            <?php $__currentLoopData = $customers_arr['indexes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!empty($index)): ?>
                                                    <th><?php echo e($index); ?></th>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $customers_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key != 'indexes'): ?>
                                            <tr>
                                                <?php if(!empty($customers_arr['indexes'])): ?>
                                                    <?php $__currentLoopData = $customers_arr['indexes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(!empty($index)): ?>
                                                            <?php if($index == 'Name'): ?>
                                                                <td><?php echo e(@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer[strtolower($index)])); ?></td>
                                                            <?php else: ?>
                                                                <td><?php echo e($customer[strtolower($index)]); ?></td>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>  
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                </tbody>
                            </table>
                        <?php else: ?> 
                            <div class="no-data-found">No Customer found in file.</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/customers/import_customers.blade.php ENDPATH**/ ?>