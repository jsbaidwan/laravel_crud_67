<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<section class="login">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="login-form">
                    <?php echo Form::open(['route' => 'password.email', 'id' => 'reset-password-form']); ?>

                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-title">
                                    <h2>Reset Password</h2>
                                </div>
                            </div>
                            <div class="form-group col-xs-12">
                                <label>Email</label>
                                <?php echo Form::email('email', '', ['placeholder' => 'Enter Your Registered Email', 'class' => 'form-control validate[required,custom[email]]']); ?>

                            </div>
                            <div class="col-xs-12">
                                <div class="comment-btn">
                                    <button type="submit" class="btn-blue btn-red">Send password reset link</button>
                                </div>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery("#reset-password-form").validationEngine();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\evergreen_crm\resources\views/users/reset_password.blade.php ENDPATH**/ ?>