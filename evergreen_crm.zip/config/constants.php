<?php    
    return [
        'CURRENCY_TYPE' => ['inr' => '₹', 'usd' => '$'],
        'CURRENCY_TYPE_LIST' => ['inr' => 'INR', 'usd' => 'USD'],
        'SUPPORTED_FIELDS_ARR' => ['name','email','phone','phone2'],
        'SMS_API_URL' => 'http://justgosms.com/http-api.php',
        'SMS_API_AUTH_KEY' => '313165766572677265656e3130301579841720',
        'SMS_API_ROUTE_ID' => '12',
        'SMS_API_SENDER_ID' => 'TRAVEL',
        'SMS_API_USER_NAME' => 'evergreen',
        'SMS_API_PASSWORD' => 'rajiv555',
    ]
?>