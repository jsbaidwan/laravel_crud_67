<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/logout', function(){
    Auth::logout();
    return redirect('/');
});
Auth::routes();
Route::get('/', 'users_controller@login');
Route::get('/login', 'users_controller@login')->name('login');
Route::post('/login', 'users_controller@login');
Route::get('/register', 'users_controller@register');
Route::get('/reset_password', 'users_controller@reset_password');
Route::get('/dashboard', 'users_controller@dashboard');
Route::get('/change_password', 'users_controller@change_password');
Route::put('/change_password', 'users_controller@change_password')->name('change_password');
Route::get('/edit_profile', 'users_controller@edit_profile');
Route::put('/edit_profile', 'users_controller@edit_profile')->name('edit_profile');
Route::get('/packages', 'packages_controller@index');
Route::get('/add_package/{id?}', 'packages_controller@add_package');
Route::post('/save_package', 'packages_controller@save_package')->name('save_package');
Route::post('/update_package_status', 'packages_controller@update_package_status');
Route::get('/customers', 'customers_controller@index');
Route::get('/add_customer/{id?}', 'customers_controller@add_customer');
Route::post('/save_customer', 'customers_controller@save_customer')->name('save_customer');
Route::post('/update_customer_status', 'customers_controller@update_customer_status');
Route::get('/get_customers/{id}/{name}', 'customers_controller@get_customers')->name('get_customers');
Route::post('/send_package', 'packages_controller@send_package')->name('send_package');
Route::get('/get_sold_packages_to_customer/{id}', 'packages_controller@get_sold_packages_to_customer');
Route::post('/sell_package', 'packages_controller@sell_package')->name('sell_package');
Route::post('/sell_package_manually', 'packages_controller@sell_package_manually')->name('sell_package_manually');
// Route::get('packages/suc', function (){
//     Session::flash('success', 'Package has been sent successfully.');
//     return redirect('/packages');
// })->name('suc_packages');
// Route::get('error/suc', function (){
//     Session::flash('error', 'An error occured while sending Package. Please try again later.');
//     return redirect('/packages');
// })->name('error_packages');
Route::get('/send_birthday_reminder', 'crone_jobs_controller@send_birthday_reminder');
Route::post('/import_customers', 'customers_controller@import_customers')->name('import_customers');
Route::get('/save_uploaded_customers/{name}', 'customers_controller@save_uploaded_customers');
Route::post('/book_flight', 'customers_controller@book_flight')->name('book_flight');
Route::get('/download_invoice/{id}/{customer_id}/{name}', 'packages_controller@download_invoice');
Route::post('/get_organizations', 'customers_controller@get_organizations');
