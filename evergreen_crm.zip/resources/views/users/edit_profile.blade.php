@extends('layouts.default')
@section('title', 'Edit Profile')
@section('content')
<style>
.dashboard-form::after{
    display:none;
}
</style>
<!-- BEGIN: Page Main-->
<div class="dashboard-content">
    <div class="dashboard-form">
        <div class="row">
           <!-- Profile -->
            <div class="col-lg-12 col-md-12 col-xs-12 padding-right-30">
                <div class="dashboard-list-box">
                    <h4 class="gray">Profile Details</h4>
                    <div class="dashboard-list-box-static">
                        <!-- Details -->
                        {!! Form::model($user_data, ['method' => 'put', 'route' => 'edit_profile', 'id' => 'edit-profile-form']) !!}
                            <div class="my-profile">
                                <label>First Name</label>
                                {!!Form::text('first_name',null, ['class' => 'validate[required]',])!!}
                                <label>Last Name</label>
                                {!!Form::text('last_name')!!}
                                <label>Email</label>
                                {!!Form::email('email',null, ['class' => 'validate[required,custom[email]]'])!!}
                                <label>Phone Number</label>
                                {!!Form::text('phone',null, ['class' => 'validate[required]'])!!}
                                <label>Phone Number2</label>
                                {!!Form::text('phone2',null, ['class' => 'validate[required]'])!!}
                                <label>Company Name</label>
                                {!!Form::text('company_name',null, ['class' => 'validate[required]'])!!}
                                <label>City</label>
                                {!!Form::text('city',null, ['class' => 'validate[required]'])!!}
                                <label>Country</label>
                                {!!Form::text('country',null, ['class' => 'validate[required]'])!!}
                            </div>
                            <button type="submit" class="btn-blue btn-red">Save Changes</button>
                        {!!Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery("#edit-profile-form").validationEngine();
    });
</script>
<!-- <div class="sb2-2">
    <div class="sb2-2-2">
        <ul>
            <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
            </li>
            <li class="active-bre"><a href="#"> Ui Form</a>
            </li>
        </ul>
    </div>
    <div class="sb2-2-3">
        <div class="row">
            <div class="col-md-12">
                <div class="box-inn-sp">
                    <div class="inn-title">
                        <h4>Update Profile</h4>
                    </div>
                    <div class="tab-inn">
                        {!! Form::model($user_data, ['method' => 'put', 'route' => 'edit_profile']) !!}
                            <div class="row">
                                <div class="input-field col s6">
                                    {!!Form::text('first_name',null, ['class' => 'validate', 'required' => true])!!}
                                    <label for="first_name1" class="active">First Name</label>
                                </div>
                                <div class="input-field col s6">
                                    {!!Form::text('last_name')!!}
                                    <label for="last_name" class="">Last Name</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s6">
                                    {!!Form::email('email',null, ['class' => 'validate','required' => true])!!}
                                    <label for="email" class="">Email</label>
                                </div>
                                <div class="input-field col s6">
                                    {!!Form::text('phone',null, ['class' => 'validate', 'required' => true])!!}
                                    <label for="phone" class="">Mobile Number</label>
                                </div>

                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <button type="submit" class="waves-effect waves-light btn-large">Save</button>
                                </div>
                            </div>
                          {!!Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->
@endsection