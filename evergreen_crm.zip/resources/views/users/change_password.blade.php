@extends('layouts.default')
@section('title', 'Change Password')
@section('content')

<div class="dashboard-content">
    <div class="">
        <div class="row">
            <div class="forgot-password">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="fp-content">
                                {!!Form::open(['route' => 'change_password', 'method' => 'put', 'id' => 'change-password-form'])!!}
                                    <div class="row">
                                        <div class="form-group col-md-4 col-xs-12">
                                            <label>Old Password</label>
                                            {!!Form::password('password', ['class' => 'validate[required]'])!!}
                                        </div>
                                        <div class="form-group col-md-4 col-xs-12">
                                            <label>New Password</label>
                                            {!!Form::password('new_password', ['class' => 'validate[required]'])!!}
                                        </div>
                                        <div class="form-group col-md-4 col-xs-12">
                                            <label>Confirm Password</label>
                                            {!!Form::password('confirm_password', ['class' => 'validate[required]'])!!}
                                        </div>
                                        <div class="col-xs-12">
                                            <div class="comment-btn">
                                                <button type="submit" class="btn-blue btn-red">Change Password</button>
                                            </div>
                                        </div>
                                    </div>
                                {!!Form::close()!!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery("#change-password-form").validationEngine();
    });
</script>
<!-- BEGIN: Page Main-->
<!-- <div class="sb2-2">
    <div class="sb2-2-2">
        <ul>
            <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
            </li>
            <li class="active-bre"><a href="#"> Ui Form</a>
            </li>
        </ul>
    </div>
    <div class="sb2-2-3">
        <div class="row">
            <div class="col-md-12">
                <div class="box-inn-sp">
                    <div class="inn-title">
                        <h4>Change Password</h4>
                    </div>
                    <div class="tab-inn">
                        {!!Form::open(['route' => 'change_password', 'method' => 'put'])!!}
                            <div class="row">
                                <div class="input-field col s4">
                                    {!!Form::password('password',['class' => 'validate', 'required' => true, 'autocomplete' => 'off'])!!}
                                    <label for="old_pass" class="active">Old Password</label>
                                </div>
                                <div class="input-field col s4">
                                    {!!Form::password('new_password',['class' => 'validate', 'required' => true])!!}
                                    <label for="new_pass" class="">New Password</label>
                                </div>
                                <div class="input-field col s4">
                                    {!!Form::password('confirm_password',['class' => 'validate', 'required' => true])!!}  
                                    <label for="c_pass" class="">Confirm Password</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s6">
                                    <button type="submit" class="waves-effect waves-light btn-large">Change Password</button>
                                </div>
                            </div>
                        {!!Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->

<!-- END: Page Main-->
@endsection