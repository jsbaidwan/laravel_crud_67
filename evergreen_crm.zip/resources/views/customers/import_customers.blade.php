@extends('layouts.default')
@section('title', 'Import Customers')
@section('content')
<style type="text/css">
    .customers-list .btn-red {
        padding: 3px 8px;
        font-weight: normal;
        font-size: 13px;
    }
    .tab-content{
        padding:28px 0px;
    }
    .dashboard-list-box.imported-customers-list-wrap h4{
        padding:0px;
    }
    .dashboard-list-box.imported-customers-list-wrap ul{
        background-color: transparent;
    }
    .dashboard-list-box.imported-customers-list-wrap ul li{
        border:none;
    }
    .nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover, .nav-tabs>li>a:hover{
        color: #fff;
        background: transparent!important;
    }
    .nav-tabs>li>a{
        color: #b5b5b5;
        background-color: transparent;
        padding: 23px 30px;
    }
    .dashboard-list-box.imported-customers-list-wrap ul li{
        background:#333333;
        padding: 0px;
    }
    .dashboard-list-box.imported-customers-list-wrap ul li.active, .dashboard-list-box ul li:focus, .dashboard-list-box ul li:hover, .dashboard-list-box ul li:hover{
        background:#005294;
        color:#fff!important;
    }
    .dashboard-list-box.imported-customers-list-wrap h4.gray{
        background:transparent;
        border:none;
    }
    .dashboard-list-box.imported-customers-list-wrap ul{
        border:none;
    }
</style>
<div class="dashboard-content customers-list">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12">
            @if(isset($result) && !empty($result))
                <div class="dashboard-list-box imported-customers-list-wrap">
                    <h4 class="gray">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#imported">Imported Customers({{@count($result['succeed'])}})</a></li>
                            <li><a data-toggle="tab" href="#rejected">Rejected Customers({{@count($result['rejected'])}})</a></li>
                    
                        </ul>
                    </h4>
                    <div class="tab-content">
                        <div id="imported" class="tab-pane fade in active">
                            <div class="table-responsive">
                                @if(isset($result['succeed']) && count($result['succeed']) > 0)
                                    <table class="basic-table booking-table table-condensed" id="customers-index-page">
                                        <thead>
                                            <tr>
                                                @if(!empty($result['indexes']))
                                                    @foreach($result['indexes'] as $key => $index)
                                                        @if(!empty($index))
                                                            <th>{{$index}}</th>
                                                        @endif
                                                    @endforeach
                                                @endif
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($result['succeed'] as $key => $customer)
                                                <tr>
                                                    <td>{{@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['first_name'])}} {{@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['last_name'])}}</td>
                                                    @if(!empty($result['indexes']))
                                                        @foreach($result['indexes'] as $key => $index)
                                                            @if(!empty($index) && $index != 'Name')
                                                                <td>{{$customer[strtolower($index)]}}</td>
                                                            @endif
                                                        @endforeach
                                                    @endif    
                                                </tr>
                                            @endforeach   
                                        </tbody>
                                    </table>
                                @else 
                                    <div class="no-data-found">No Customer imported.</div>
                                @endif
                            </div>
                        </div>
                         <div id="rejected" class="tab-pane fade">
                            <div class="dashboard-list-box">
                                <div class="table-responsive">
                                    @if(isset($result['rejected']) && count($result['rejected']) > 0)
                                        <table class="basic-table booking-table table-condensed" id="customers-index-page">
                                            <thead>
                                                <tr>
                                                    @if(!empty($result['indexes']))
                                                        @foreach($result['indexes'] as $key => $index)
                                                            @if(!empty($index))
                                                                <th>{{$index}}</th>
                                                            @endif
                                                        @endforeach
                                                        <th>Reason</th>
                                                    @endif
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($result['rejected'] as $key => $customer)
                                                    <tr>
                                                        <td>{{@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['first_name'])}} {{@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer['last_name'])}}</td>
                                                        @if(!empty($result['indexes']))
                                                            @foreach($result['indexes'] as $key => $index)
                                                                @if(!empty($index) && $index != 'Name')
                                                                    <td>{{$customer[strtolower($index)]}}</td>
                                                                @endif
                                                            @endforeach
                                                        @endif  
                                                        <td>
                                                            @foreach($customer['reason'] as $key => $reason)
                                                                <div style="color:red;">{{$reason}}</div>
                                                            @endforeach
                                                        </td>
                                                    </tr>
                                                @endforeach   
                                            </tbody>
                                        </table>
                                    @else 
                                        <div class="no-data-found">All customers imported successfully.</div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @else
                <div class="dashboard-list-box">
                    <h4 class="gray">Import Customers({{@count($customers_arr)-1}})
                        <a style="margin-left:10px;" href="{{url('/customers')}}" class="btn-blue btn-red pull-right">Cancel</a>
                        <a onclick="save_customers();" href="{{url('/save_uploaded_customers')}}/{{$org_file_name}}" class="btn-blue btn-red pull-right">Save Customers</a>
                    </h4>
                    <div class="table-responsive">
                        @if(count($customers_arr) > 1)
                            <table class="basic-table booking-table table-condensed" id="customers-index-page">
                                <thead>
                                    <tr>
                                        @if(!empty($customers_arr['indexes']))
                                            @foreach($customers_arr['indexes'] as $key => $index)
                                                @if(!empty($index))
                                                    <th>{{$index}}</th>
                                                @endif
                                            @endforeach
                                        @endif
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($customers_arr as $key => $customer)
                                        @if($key != 'indexes')
                                            <tr>
                                                @if(!empty($customers_arr['indexes']))
                                                    @foreach($customers_arr['indexes'] as $key => $index)
                                                        @if(!empty($index))
                                                            @if($index == 'Name')
                                                                <td>{{@preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $customer[strtolower($index)])}}</td>
                                                            @else
                                                                <td>{{$customer[strtolower($index)]}}</td>
                                                            @endif
                                                        @endif
                                                    @endforeach
                                                @endif  
                                            </tr>
                                        @endif
                                    @endforeach   
                                </tbody>
                            </table>
                        @else 
                            <div class="no-data-found">No Customer found in file.</div>
                        @endif
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection