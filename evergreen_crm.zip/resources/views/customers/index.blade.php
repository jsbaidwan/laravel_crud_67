@extends('layouts.default')
@section('title', 'Customers')
@section('content')
<style type="text/css">
    .customers-list .btn-red {
        padding: 3px 8px;
        font-weight: normal;
        font-size: 13px;
    }
    .my-profile textarea {
        height:auto !important;
    }
    #customers-index-page .opacity {
        opacity:0.5;
    }
    table.basic-table th {
        background-color: #303030;
    }
    table.basic-table th, table.basic-table td {
        padding:10px;
    }
    .table-condensed > tbody > tr > td, .table-condensed > tbody > tr > th, .table-condensed > tfoot > tr > td, .table-condensed > tfoot > tr > th, .table-condensed > thead > tr > td, .table-condensed > thead > tr > th {
        padding:20px 10px;
    }
</style>
<div class="dashboard-content customers-list">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12">
            <div class="dashboard-list-box">
                <h4 class="gray">All Customers
                    <button style="margin-left:10px;" class="btn-blue btn-red pull-right" onclick="manage_customer('');">+ Add Customer</button>
                    <button class="btn-blue btn-red pull-right" data-toggle="modal" data-target="#import_customers"><i class="fa fa-download" aria-hidden="true"></i> Import Customers</button>
                </h4>
                <div class="table-responsive">
                    @if(count($customers_arr) > 0)
                        <table class="basic-table booking-table table-condensed" id="customers-index-page">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Date of birth</th>
                                    <th>Marriage anniversary</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($customers_arr as $customer)
                                    <tr class="customer_id_{{$customer->id}}">
                                        <td>{{$customer->first_name}} {{$customer->last_name}}</td>
                                        <td>{{$customer->email}}</td>
                                        <td>{{$customer->phone}}</td>
                                        <td>
                                            @php 
                                                if(!empty($customer->dob)) {
                                                    $customer->dob = date('d M, Y', strtotime($customer->dob));    
                                                }
                                            @endphp
                                            {{$customer->dob}}
                                        </td>
                                        <td>
                                            @php 
                                                if(!empty($customer->marriage_anniversary)) {
                                                    $customer->marriage_anniversary = date('d M, Y', strtotime($customer->marriage_anniversary));    
                                                }
                                            @endphp
                                            {{$customer->marriage_anniversary}}
                                        </td>
                                        @if($customer->status)
                                            <td><span data-toggle="tooltip" data-placement="top" title="Change Status" class="paid t-box" status="0" onclick="change_status('{{$customer->id}}', this);">Active</span></td>
                                        @else
                                            <td><span data-toggle="tooltip" data-placement="top" title="Change Status" class="cancel t-box" status="1" onclick="change_status('{{$customer->id}}', this);">Inactive</span></td>
                                        @endif
                                        <td>
                                            @php
                                                $enabled = 'display:none;';
                                                $disabled = '';
                                                if($customer->status) {
                                                    $disabled = 'display:none;';
                                                    $enabled = '';
                                                }
                                            @endphp
                                            <a style="{{$enabled}}" data-toggle="tooltip" data-placement="top" title="Edit Customer" href="javascript:;" class="button gray enabled" onclick="manage_customer('{{$customer->id}}');"><i class="sl sl-icon-pencil"></i></a>
                                            <a style="{{$disabled}}" data-toggle="tooltip" data-placement="top" title="Edit Customer" href="javascript:;" class="button gray opacity disabled"><i class="sl sl-icon-pencil"></i></a>
                                            <a style="{{$enabled}}" data-toggle="tooltip" data-placement="top" title="Book Flight" href="javascript:;" class="button gray enabled" onclick="book_flight('{{$customer->id}}');"><i class="fa fa-ticket"></i></a>
                                            <a style="{{$disabled}}" data-toggle="tooltip" data-placement="top" title="Book Flight" href="javascript:;" class="button gray opacity disabled"><i class="fa fa-ticket"></i></a>
                                            <a style="{{$enabled}}" data-toggle="tooltip" data-placement="top" title="Sell Package Manually" href="javascript:;" class="button gray enabled" onclick="show_sell_package_manually_popup('{{$customer->id}}');"><i class="sl sl-icon-plane"></i></a>
                                            <a style="{{$disabled}}" data-toggle="tooltip" data-placement="top" title="Sell Package Manually" href="javascript:;" class="button gray opacity disabled"><i class="sl sl-icon-plane"></i></a>
                                            <a data-toggle="tooltip" data-placement="top" title="View History" href="javascript:;" class="button gray" onclick="get_sold_packages('{{$customer->id}}');"><i class="fa fa-history" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else 
                        <div class="no-data-found">No Customer added yet.</div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$( document ).ready(function() {

    $('#customers-index-page').DataTable( {
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "aaSorting": []
    });
    $('#sell_package_manually').on('hidden.bs.modal', function () {
        $('#sell-package-manually-form').trigger("reset");
    });
    $('#book-flight-model').on('hidden.bs.modal', function () {
        $('#book-flight-form').trigger("reset");
    });
    $('.flight-type').on('change', function() {
        if(this.value == 'round_trip') {
            $('.arrival-date').show();
        }
        else {
            $('.arrival-date').hide();        
        }
    });
});
</script>
<script type="text/javascript">
    function get_sold_packages(customer_id) {
        if(customer_id != '') {
            var url = "{{url('/get_sold_packages_to_customer')}}/"+customer_id;  
            $("#sold_packages").modal('show'); 
            $("#sold_packages .modal-body").load(url);
        }
        else {
            alert_msg('Invalid Request', 'error');
        }     
    }
    function manage_customer(id) {

        $("#add_customer").modal('show');
        var url = "{{url('/add_customer')}}";
        if(id == '') {
            $('#add_customer .modal-title').text('Add Customer');
            $('#add_customer .submit-btn').text('Add');        
        }
        else {
            $('#add_customer .modal-title').text('Update Customer Detail');
            $('#add_customer .submit-btn').text('Update');
            var url = "{{url('/add_customer')}}/"+id;     
        }
        $("#add_customer .modal-body").load(url);
    }
    function save_customer() {
        if(jQuery("#add-customer-form").validationEngine('validate')) {
            $('#add-customer-form').submit();
        }
    }

    function upload_customers() {
        if(jQuery('#import-customer-form').validationEngine('validate')) {
            $('#import-customer-form').submit();
        }
    }

    function change_status(id,thiss) {
        var status = $(thiss).attr('status');
        if(id != '' && status != '') {
            if(confirm('Are you sure to change to status of customer?')) {
                $.ajax({
                    type: 'POST',
                    url: "{{url('/update_customer_status')}}",
                    data: {
                        _token:'{{csrf_token()}}',
                        status: status,
                        id: id,
                    },
                    success: function(data) 
                    { 
                        if(data == 'suc') {
                            if(status == 1) {
                                $(thiss).text('Active');
                                $(thiss).removeClass('cancel');
                                $(thiss).addClass('paid');
                                $(thiss).attr('status', 0);
                                $('#customers-index-page .customer_id_'+id+' .enabled').css('display', 'block');
                                $('#customers-index-page .customer_id_'+id+' .enabled').css('display', 'inline-block');
                                $('#customers-index-page .customer_id_'+id+' .disabled').css('display', 'none');
                            }
                            else {
                                $(thiss).removeClass('paid');
                                $(thiss).addClass('cancel');
                                $(thiss).text('Inactive');
                                $(thiss).attr('status', 1);
                                $('#customers-index-page .customer_id_'+id+' .disabled').css('display', 'block');
                                $('#customers-index-page .customer_id_'+id+' .disabled').css('display', 'inline-block');
                                $('#customers-index-page .customer_id_'+id+' .enabled').css('display', 'none');
                            }
                            alert_msg('Customer status has been updated successfully.', 'success');
                        }
                        else {
                            alert_msg('An error occured while updating status.', 'error');
                        }
                    },
                    error: function(data){
                        var errors = data.responseJSON;
                        $.each(errors.errors, function( key, value ) {
                            alert_msg(value, 'error');
                        });
                    }
                });
            } 
        }
        else {
            alert_msg('Invalid Request.', 'error');
        }
    }

    function show_sell_package_manually_popup(customer_id) {
        if(customer_id != '') {
            $('#customer-id').val(customer_id);
            $('#sell_package_manually').modal('show');
        }
        else {
            alert_msg('Customer id missing.', 'error');    
        }
    }

    function sell_package_manually() {
        if(jQuery("#sell-package-manually-form").validationEngine('validate')) {
            var form_data = $('#sell-package-manually-form').serialize();
            $.ajax({
                type: 'POST',
                url: "{{url('/sell_package_manually')}}",
                data: form_data,
                success: function(data) 
                { 
                    if(data == 'suc') {
                        $('#sell_package_manually').modal('hide');
                        $('#sell-package-manually-form').trigger("reset");
                        alert_msg('Package has been sold successfully.', 'success');
                    }
                    else {
                        alert_msg('An error occured while selling package.', 'error');
                    }
                },
                error: function(data){
                    var errors = data.responseJSON;
                    $.each(errors.errors, function( key, value ) {
                        alert_msg(value, 'error');
                    });
                }
            });       
        }
    }
    function book_flight(customer_id) {
        if(customer_id != '') {
            $('#book-flight-customer-id').val(customer_id);
            $('#book-flight-model').modal('show');
        }
        else {
            alert_msg('Customer id missing.', 'error');    
        }
    }

    function save_booked_flight_data() {
        if(jQuery("#book-flight-form").validationEngine('validate')) {
            var form_data = $('#book-flight-form').serialize();
            $.ajax({
                type: 'POST',
                url: "{{url('/book_flight')}}",
                data: form_data,
                success: function(data) 
                { 
                    if(data == 'suc') {
                        $('#book-flight-model').modal('hide');
                        $('#book-flight-form').trigger("reset");
                        alert_msg('Flight has been booked successfully.', 'success');
                    }
                    else {
                        alert_msg('An error occured while booking flight.', 'error');
                    }
                },
                error: function(data){
                    var errors = data.responseJSON;
                    $.each(errors.errors, function( key, value ) {
                        alert_msg(value, 'error');
                    });
                }
            }); 
        }
    }
    $(document).on("click",".auto-complete-wrap .options-wrap li",function() {
        $('#add-customer-form .organization-name').val($(this).text());
        $('#add-customer-form .organization-location').val($(this).attr('location'));
        $('#add-customer-form .organization-gst-number').val($(this).attr('gst_number'));
        $('.auto-complete-wrap .options-wrap').html('');
        $('.auto-complete-wrap .auto-complete-inner-wrap').hide();
    });
    function get_organizations(thiss) {
        var organization = $(thiss).val();
        if(organization == '') {
            $('.auto-complete-wrap .options-wrap').html('');
            $('.auto-complete-wrap .auto-complete-inner-wrap').hide();    
        }
        else {
            $.ajax({
                type: 'POST',
                url: "{{url('/get_organizations')}}",
                data: {
                    _token:'{{csrf_token()}}',
                    organization: organization,
                },
                success: function(data) 
                { 
                    if(data != '') {
                        $('.auto-complete-wrap .options-wrap').html(data);    
                        $('.auto-complete-wrap .auto-complete-inner-wrap').show();
                    }
                    else {
                        $('.auto-complete-wrap .auto-complete-inner-wrap').hide();
                    }
                },
                error: function(data){
                    var errors = data.responseJSON;
                    $.each(errors.errors, function( key, value ) {
                        alert_msg(value, 'error');
                    });
                }
            });
        }
    }
    function close_autocomplete() {
        $('.auto-complete-wrap .auto-complete-inner-wrap').hide();    
    }
</script>

<!-- POP-UP TO MANAGE CUSTOMER -->
<div id="add_customer" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Update Customer Detail</h4>
            </div>
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="submit" onclick="save_customer();" class="btn btn-danger submit-btn">Update</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- POP-UP TO IMPORT CUSTOMERS -->
<div id="import_customers" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            {!! Form::open(['route' => 'import_customers', 'id' => 'import-customer-form', 'files' => true]) !!}
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Import Customers</h4>
                </div>
                <div class="modal-body">
                    <label>Upload CSV file</label>
                    {!! Form::file('customers_data', ['class' => 'form-control validate[required]']) !!}
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" onclick="upload_customers();">Upload Customers</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</div>

<!-- POP-UP TO SHOW SOLD PACKAGES TO CUSTOMER -->
<div id="sold_packages" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Sold Packages</h4>
            </div>
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- POP-UP TO SELL PACKAGE MANUALLY -->
<div id="sell_package_manually" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Sell Package Manually</h4>
            </div>
            <div class="modal-body">
                {!! Form::open(['route' => 'sell_package_manually', 'id' => 'sell-package-manually-form']) !!}
                    {!! Form::hidden('customer_id', null, ['id' => 'customer-id']) !!}
                    <div class="my-profile">
                        <label>Title</label>
                        {!! Form::text('package_title', null, ['class' => 'form-control validate[required]', 'required' => true]) !!}
                        <!-- <label>Tour Location</label>
                        {!! Form::text('package_duration', null, ['class' => 'form-control validate[required]', 'required' => true]) !!} -->
                        <label>Duration</label>
                        <div class="row">
                            <div class="col-md-3">
                                {!! Form::text('days', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]]', 'required' => true]) !!}
                            </div>
                            <div class="col-md-3">
                                Days
                            </div>
                            <div class="col-md-3">
                                {!! Form::text('nights', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]]', 'required' => true]) !!}
                            </div>
                            <div class="col-md-3">
                                Nights
                            </div>
                        </div>
                        <label>Departure date</label>
                        <div class="input-group date">
                            {!! Form::text('package_departure_date', null, ['class' => 'form-control validate[required] datepicker']) !!}
                            <div class="input-group-addon">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                            </div>
                        </div>  
                        <label>Price</label>
                        {!! Form::text('package_price', null, ['class' => 'form-control validate[required]', 'required' => true]) !!}
                        <label>Select Currency</label>
                        {!! Form::select('currency_type', Config::get('constants.CURRENCY_TYPE_LIST'), null, ['class' => 'form-control validate[required]', 'required' => true]) !!}
                        <label>Payment Due date</label>
                        <div class="input-group date">
                            {!! Form::text('payment_due_date', null, ['class' => 'form-control validate[required] payment-due-date datepicker']) !!}
                            <div class="input-group-addon">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                            </div>
                        </div>
                        <label>Inclusion (Add multiple enteries by pressing enter key.)</label>
                        {!! Form::textarea('inclusion', null, ['class' => 'form-control text-area-field', 'rows' => '3']) !!}
                        <label>Exclusion (Add multiple enteries by pressing enter key.)</label>
                        {!! Form::textarea('exclusion', null, ['class' => 'form-control text-area-field', 'rows' => '3']) !!}
                    </div>
                {!! Form::close() !!}    
            </div>
            <div class="modal-footer">
                <button type="submit" onclick="sell_package_manually();" class="btn btn-danger submit-btn">Sell Package</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- POP-UP TO SELL PACKAGE MANUALLY -->
<div id="book-flight-model" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Book Flight</h4>
            </div>
            <div class="modal-body">
                {!! Form::open(['route' => 'book_flight', 'id' => 'book-flight-form']) !!}
                    {!! Form::hidden('customer_id', null, ['id' => 'book-flight-customer-id']) !!}
                    <div class="my-profile">
                        <label>Ticket Number</label>
                        {!! Form::text('ticket_number', null, ['class' => 'form-control validate[required,custom[number]]',]) !!}
                        <label>PNR Number</label>
                        {!! Form::text('pnr_number', null, ['class' => 'form-control validate[required]',]) !!}
                        <label>Airline Name</label>
                        {!! Form::text('airways_name', null, ['class' => 'form-control validate[required]',]) !!}
                        <label>Flight Type</label>
                        {!! Form::select('flight_type', ['round_trip' => 'Round Trip', 'one_way' => 'One Way'], null, ['class' => 'form-control validate[required] flight-type', 'required' => true]) !!}
                        <label>Departure date</label>
                        <div class="input-group date">
                            {!! Form::text('departure_date', null, ['class' => 'form-control validate[required] datepicker']) !!}
                            <div class="input-group-addon">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                            </div>
                        </div> 
                        <div class="arrival-date">
                            <label>Arrival date</label>
                            <div class="input-group date">
                                {!! Form::text('arrival_date', null, ['class' => 'form-control validate[required] datepicker']) !!}
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                </div>
                            </div>  
                        </div> 
                        <label>Flight From</label>
                        {!! Form::text('flight_from', null, ['class' => 'form-control validate[required]',]) !!}
                        <label>Flight To</label>
                        {!! Form::text('flight_to', null, ['class' => 'form-control validate[required]',]) !!}
                        <label>Price</label>
                        {!! Form::text('price', null, ['class' => 'form-control validate[required]', 'required' => true]) !!}  
                        <label>Select Currency</label>
                        {!! Form::select('currency_type', Config::get('constants.CURRENCY_TYPE_LIST'), null, ['class' => 'form-control validate[required]', 'required' => true]) !!}
                        <label>Payment Due date</label>
                        <div class="input-group date">
                            {!! Form::text('payment_due_date', null, ['class' => 'form-control validate[required] payment-due-date datepicker']) !!}
                            <div class="input-group-addon">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                            </div>
                        </div>                       
                    </div>
                {!! Form::close() !!}    
            </div>
            <div class="modal-footer">
                <button type="submit" onclick="save_booked_flight_data();" class="btn btn-danger submit-btn">Book Flight</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@endsection