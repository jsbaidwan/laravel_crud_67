@php 
    //echo Request::path();die;
    $meanu_arr = array(
        'Dashboard' => array(
            'url' => url('/dashboard'),
            'icon' => 'fa fa-tachometer',
            'sub_menus' => array('dashboard'),
        ),
        'Packages' => array(
            'url' => url('/packages'),
            'icon' => 'fa fa-plane',
            'sub_menus' => array('packages', 'manage_package'),
        ),
        'Customers' => array(
            'url' => url('/customers'),
            'icon' => 'fa fa-users',
            'sub_menus' => array('customers', 'manage_user', 'import_customers','save_uploaded_customers'),
        ),
    );
@endphp
<div class="dashboard-nav">
    <div class="dashboard-nav-inner">
        <ul>
            @foreach($meanu_arr as $menu_name => $sub_menus)
                @php 
                    $current_page = Request::path();
                    if(strpos(Request::path(), '/') !== false) {
                        $current_page = explode('/', Request::path());
                        $current_page = $current_page[0];
                    } 
                    $class = '';
                    if(in_array($current_page, $sub_menus['sub_menus'])) {
                        $class = 'active';
                    }
                @endphp
                <li class="{{$class}}"><a href="{{$sub_menus['url']}}"><i class="{{$sub_menus['icon']}}"></i> {{$menu_name}}</a></li>
            @endforeach
        </ul>
    </div>
</div>
<!-- <div class="sb2-1">
    <div class="sb2-12">
        <ul>
            <li><img src="{{asset('public/images/placeholder.jpg')}}" alt="">
            </li>
            <li>
                <h5>{{Auth::user()->first_name}} {{Auth::user()->last_name}}</h5>
            </li>
            <li></li>
        </ul>
    </div>
    <div class="sb2-13">
        <ul class="collapsible" data-collapsible="accordion">
            @foreach($meanu_arr as $menu_name => $sub_menus)
                @php 
                    $class = '';
                    if(in_array(Request::path(), $sub_menus['sub_menus'])) {
                        $class = 'menu-active';
                    }
                @endphp
                <li>
                    <a href="{{$sub_menus['url']}}" class="{{$class}}"><i class="fa {{$sub_menus['icon']}}" aria-hidden="true"></i>{{$menu_name}}</a>
                </li>        
            @endforeach
        </ul>
    </div>
</div> -->