<!DOCTYPE html>
<html>

<head>
    <title>Evergreen-@yield('title')</title>
    <!--== META TAGS ==-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--== FAV ICON ==-->
    <link rel="shortcut icon" href="{{asset('images/fav.ico')}}">

    <!--== ALL CSS FILES ==-->
    <link rel="stylesheet" href="{{asset('public/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('public/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('public/css/flaticon.css')}}">
    <link rel="stylesheet" href="{{asset('public/css/plugin.css')}}">
    <link rel="stylesheet" href="{{asset('public/css/dashboard.css')}}" />
    <link rel="stylesheet" href="{{asset('public/css/icons.css')}}" />
    <link rel="stylesheet" href="{{asset('public/css/font-awesome.min.css')}}" />
    <link rel="stylesheet" href="{{asset('public/css/validationEngine.jquery.css')}}" />
    <link rel="stylesheet" href="{{asset('public/css/bootstrap-datepicker3.min.css')}}" />
    <link rel="stylesheet" href="{{asset('public/css/dataTables.bootstrap.min.css')}}" />

    <!--======== SCRIPT FILES =========-->
    <script src="{{asset('public/js/jquery-3.2.1.min.js')}}"></script>
    <script src="{{asset('public/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/js/plugin.js')}}"></script>
    <script src="{{asset('public/js/preloader.js')}}"></script>
    <script src="{{asset('public/js/main.js')}}"></script>
    <script src="{{asset('public/js/dashboard-custom.js')}}"></script>
    <script src="{{asset('public/js/jpanelmenu.min.js')}}"></script>
    <script src="{{asset('public/js/counterup.min.js')}}"></script>
    <script src="{{asset('public/js/jquery.validationEngine-en.js')}}"></script>
    <script src="{{asset('public/js/jquery.validationEngine.js')}}"></script>
    <script src="{{asset('public/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('public/js/jdataTables.bootstrap.min.js')}}"></script>
</head>
@php
    $wrap_class = '';
    if(Auth::check()) {
        $wrap_class = 'sb2';
    }
@endphp
<body> 
    <style type="text/css">
        .alert_msgs {
            max-width: 100%;
            margin: 0 auto;
            position: fixed;
            top: 30px;
            transform: translate(-50%, -20%);
            left: 50%;
            width: 400px;
            text-align: center;
            z-index: 9999999;
        }
        .js-alert-msgs {
            display:none;
        }
        .modal{
            z-index:99999;
        }
        .no-data-found {
            text-align: center;
            font-size: 20px;
            padding: 40px 0 10px 0;
        }
        .t-box {
            cursor:pointer;
        }
        .datepicker-days .table-condensed {
            width:100%;
        }
    </style>
    <script type="text/javascript">
        function hide_alerts() {
            setTimeout(function() {
                $('.alert_msgs').fadeOut('slow')
            }, 3000);
        }
        function alert_msg (text,type) {
            $('.js-alert-msgs').show();
            $('.js-alert-msgs').text(text);
            if(type == 'success') {
                $('.js-alert-msgs').addClass('alert-success');
                $('.js-alert-msgs').removeClass('alert-danger');
            }
            else {
                $('.js-alert-msgs').addClass('alert-danger');
                $('.js-alert-msgs').removeClass('alert-success');
            }
            hide_alerts();
        }      
    </script>
    @if ($errors->any())
        @foreach ($errors->all() as $error)
            <div class="alert alert-danger alert_msgs">
                {{$error}}
            </div>
        @endforeach
        <script type="text/javascript">
            hide_alerts();
        </script>
    @endif
    @if(Session::has('success') || Session::has('error'))
        @php
            $alert_class = '';
            $alert_msg = '';
            if(Session::has('success')) {
                $alert_class = 'alert-success';
                $alert_msg = Session::get('success');
            }
            else {
                $alert_class = 'alert-danger';
                $alert_msg = Session::get('error');
            }
        @endphp
        <div class="alert {{$alert_class}} alert_msgs">
            {{ $alert_msg }}
        </div>
        <script type="text/javascript">
            hide_alerts();
        </script>
    @endif  
    <div class="alert alert_msgs js-alert-msgs">
    </div>
    <div id="preloader">
        <div id="status"></div>
    </div>
    <div id="container-wrapper">
        <div id="dashboard">
            @yield('content')
        </div>
    </div>
</body>

</html>