@extends('layouts.default')
@section('title', 'Dashboard')
@section('content')
<style>
.not-found {
    color:#000;
    font-size:18px;
}
</style>
<div class="dashboard-content">
    <div class="row">

        <!-- Item -->
        <div class="col-lg-4 col-md-6 col-xs-6">
            <div class="dashboard-stat color-1">
                <div class="dashboard-stat-content">
                    <h4>{{$total_sold_packages_count}}</h4> <span>Sold Packages</span>
                </div>
                <div class="dashboard-stat-icon"><i class="im im-icon-Line-Chart"></i></div>
                <div class="dashboard-stat-item">
                    <p>Total No. of sold packages</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-xs-6">
            <div class="dashboard-stat color-3">
                <div class="dashboard-stat-content">
                    <h4>{{$total_booked_flights}}</h4> <span>Booked Flights</span>
                </div>
                <div class="dashboard-stat-icon"><i class="fa fa-plane"></i></div>
                <div class="dashboard-stat-item">
                    <p>Total No. of booked flights.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-xs-6">
            <div class="dashboard-stat color-4">
                <div class="dashboard-stat-content">
                    <h4>{{$total_customer}}</h4> <span>Total Customers</span>
                </div>
                <div class="dashboard-stat-icon"><i class="im im-icon-Add-UserStar"></i></div>
                <div class="dashboard-stat-item">
                    <p>Total active customers.</p>
                </div>
            </div>
        </div>


    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12 traffic">
            <div class="dashboard-list-box">
                <h4 class="gray">Recent Sold Packages</h4>
                <div class="table-box">
                    <table class="basic-table">
                        <thead>
                            <tr>
                                <th>Package Name</th>
                                <th>Customer Name</th>
                                <th>Customer Phone</th>
                                <th>Price</th>
                                <th>Duration</th>
                                <!-- <th>Purchaged Date</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($recent_bookings_arr) > 0)
                                @foreach($recent_bookings_arr as $recent_booking) 
                                    <tr>
                                        <td>{{$recent_booking->package_title}}</td>
                                        <td>{{$recent_booking->customers['first_name']}} {{$recent_booking->customers['last_name']}}</td>
                                        <td>{{$recent_booking->customers['phone']}}</td>
                                        <td>
                                            @php echo Config::get('constants.CURRENCY_TYPE.'.$recent_booking->currency_type);echo number_format($recent_booking->package_price); @endphp
                                        </td>
                                        <td>{{$recent_booking->package_duration}}</td>
                                        <!-- <td>{{@date('j M, Y', @strtotime($recent_booking->created_at))}}</td> -->
                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="6" class="text-center not-found">No package sold recently.</td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12 traffic">
            <div class="dashboard-list-box">
                <h4 class="gray">Recent Booked Flights</h4>
                <div class="table-box">
                    <table class="basic-table">
                        <thead>
                            <tr>
                            <th>Ticket No.</th> 
                            <th>Customer Name</th>
                            <th>Customer Phone</th>
                            <th>PNR No.</th>   
                            <th>Airways</th>
                            <th>Price</th>   
                            <th>Flight Details</th> 
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($recent_booked_flights_arr) > 0)
                                @foreach($recent_booked_flights_arr as $booked_flight) 
                                <tr>
                                    <td>{{$booked_flight->ticket_number}}</td>
                                    <td>{{$booked_flight->customers['first_name']}} {{$booked_flight->customers['last_name']}}</td>
                                    <td>{{$booked_flight->customers['phone']}}</td>
                                    <td>{{$booked_flight->pnr_number}}</td>
                                    <td>{{$booked_flight->airways_name}}</td>
                                    <td>
                                        @php echo Config::get('constants.CURRENCY_TYPE.'.$booked_flight->currency_type);echo number_format($booked_flight->price); @endphp
                                    </td>
                                    <td>
                                        <div>
                                            {{$booked_flight->flight_from}} <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> {{$booked_flight->flight_to}} ({{date('d, M Y', @strtotime($booked_flight->departure_date))}})
                                        </div>
                                        @if($booked_flight->flight_type == 'round_trip')
                                            <div>
                                                {{$booked_flight->flight_to}} <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> {{$booked_flight->flight_from}} ({{date('d, M Y', @strtotime($booked_flight->arrival_date))}})
                                            </div>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="6" class="text-center not-found">No flight booked recently.</td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-xs-12 traffic">
            <div class="dashboard-list-box">
                <h4 class="gray">Recent Customers</h4>
                <div class="table-box">
                    <table class="basic-table">
                        <thead>
                            <tr>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Registration Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($recent_customers_arr) > 0)
                                @foreach($recent_customers_arr as $recent_customer) 
                                    <tr>
                                        <td>{{$recent_customer->first_name}} {{$recent_customer->last_name}}</td>
                                        <td>{{$recent_customer->email}}</td>
                                        <td>{{$recent_customer->phone}}</td>
                                        <td>{{@date('j M, Y', @strtotime($recent_customer->created_at))}}</td>
                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="6" class="text-center not-found">No customer added recently.</td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection