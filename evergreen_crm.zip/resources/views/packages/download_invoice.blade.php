<style>
    .clearfix:after {
        content: "";
        display: table;
        clear: both;
    }
    
    a {
    color: #5D6975;
    text-decoration: underline;
    }
    
    .page, .textLayer {
    position: relative;
    margin: 0 auto; 
    color: #1d1d1d;
    background: #fff; 
    font-family: 'Roboto', sans-serif; 
    font-size: 14px;
    line-height: 20px;
    font-weight: 500;
    }
    .header{
        margin-top: 20px;
    } 
    .text-left{
        text-align: left;
    }
    .text-center{
        text-align: center;
    }
    .text-right{
        text-align: right;
    }
    .d-inline img, .d-inline{
        display: inline;
        vertical-align: middle;
    }
    .borderafter {
        border-bottom: 1px solid #796b6b;
        width: 400px;
        margin: 0;
        opacity: 0.2;
    }
    hr.line {
        border: 2px solid #009966;
        width: 100%;
    }
    hr.line1 {
        border: 2px solid #3399cc;
        width: 100%;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 10px;
    }
    table,
    td,
    th {
      border-collapse: collapse;
    }
    table th,
    table td {
        text-align: left;
        padding:10px 0px;
        vertical-align: top;
        line-height: 20px;
    }
    .border-table th, .border-table
    td {
      padding: 10px;
      border: solid 1px #3399cc;
    }
    .border-table{
        border-bottom: solid 4px #3399cc; 
    }
    .head-table{
        background: #3399cc;
        color: #fff;
    }
    .totalplan{
     width: 400px;
    float: right;
    position: relative;
    }
    .totalplan:before {
    
        position: absolute;
        top: 0;
        right: 0;
        width: 400px;
        border-top: 2px solid  #e1dedec4;
        content: '';
    }
    .border-top-bo {
        border-top: 2px solid #ccc;
        border-bottom: 2px solid #ccc;
    }
    html{margin:auto 10px}
    .border-table.text-left td, .total-wrap td {
        font-size:12px;
    }
</style>
<?php //echo '<pre>';print_r($data);die;?>
<table class="header">
    <tbody>
        <tr>
            <td  style="padding-bottom:0px;">
                <table>
                    <tbody>
                    <tr>
                        <td style="font-size: 36px;font-weight: 800;padding: 20px 0;width:420px;"><span style="color:#009966;">EVERGREEN</span> <span style="color:#003399;">TRAVELS</span></td>
                    </tr>
                    <tr>
                        <td class="d-inline" style="white-space: nowrap;line-height: 30px;">SCO324-325 SECOND FLOOR SECTOR 38B,<br> CHANDIGRAH-160036, PUNJAB, INDIA
                            <br/><img style="width:20px;margin-top:3px;padding-right: 8px;" src="{{asset('public/images/invoice_images/call.png')}}"> +91 9958600585 <span style="color: #019866;font-size: 20px;padding: 0 8px;">|</span>
                            <img style="width:20px;padding-right: 8px;margin-top:3px;" src="{{asset('public/images/invoice_images/mess.png')}}"> info.evergreentravels@gmail.com
                            <br>G.S.T. NO: 04ABSPBI527E1Z4
                            <br>ACC. NO: 1212121212121212
                        </td>
                    </tr>
                </tbody>
                </table>
            </td>
            <td class="text-right">
                <img width="240px" src="{{asset('public/images/invoice_images/logo.png')}}">
            </td>

        </tr>
        <tr>
            <td style="padding-top:10px;"><hr class="borderafter" /></td>
        </tr>
        <tr class="clearfix">
            <td class="text-left" style="line-height: 25px; padding-top:0px;">
                Txn No. : 111111
                <br/>Date: {{@date('d M, Y')}}
                <br/>Due Dt. : {{@date('d M, Y', strtotime($data->payment_due_date))}}
            </td>
            @if($data->customers->organization != '')
                <td style="float:right; line-height: 25px;white-space: nowrap;padding:0;"><span class="text-right">
                    <b>{{$data->customers->organization}}</b>
                    <br/>{{$data->customers->organization_location}}, G.S.T. NO. {{$data->customers->organization_gst_number}}</span>
                </td>
            @endif
        </tr>
        <tr>
            <td colspan="2" style="line-height: 22px;">
                <span style="font-size:22px;color:#009966"><b>{{$data->customers->first_name}} {{$data->customers->last_name}}</b><br><span style="font-size:11px;">(@if($data->customers->email != ''){{$data->customers->email}} - @endif{{$data->customers->phone}})</span></span>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <img width="773px" src="{{asset('public/images/invoice_images/info.png')}}">
            </td>
        </tr>
        <tr>
            <td colspan="2"><hr class="line" /></td>
        </tr>
        @if($type == 'flight')
            <tr>
                <td colspan="2">
                    <table class="border-table text-left">
                        <thead class="head-table text-left">
                            <tr>
                                <th>Ticket No.</th>
                                <th>Airline Name</th>
                                <th>PNR No.</th>
                                <th>Sector(s) / Flight Detail</th>
                                <th>Basic</th>
                                <th>Taxes</th>
                                <th>Total ({{@strtoupper($data->currency_type)}})</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{{$data->ticket_number}}</td>
                                <td>{{$data->airways_name}}</td>
                                <td>{{$data->pnr_number}}</td>
                                <td>
                                    {{$data->flight_from}} <img width="15px" style="margin-top:3px;" src="{{asset('public/images/invoice_images/arrow.png')}}"> {{$data->flight_to}} ({{@date('d M, Y', strtotime($data->departure_date))}})
                                    @if($data->flight_type == 'round_trip')
                                        <br/>
                                        {{$data->flight_to}} <img width="15px" style="margin-top:3px;" src="{{asset('public/images/invoice_images/arrow.png')}}"> {{$data->flight_from}} ({{@date('d M, Y', strtotime($data->arrival_date))}})
                                    @endif
                                </td>
                                <td>{{@number_format($data->price)}}</td>
                                <td>1,928.00</td>
                                <td>20,653.00</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <table class="total-wrap">
                        <tbody>
                            <tr>
                                <td style="width:50%;">
                                </td>
                                <td>
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td style="text-align:right;" class="text-right"><b>Total</b></td>
                                                <td style="text-align:right;" class="text-right"><b>37,450.00</b></td>
                                                <td style="text-align:right;" class="text-right"><b>3,856.00</b></td>
                                                <td style="text-align:right;" class="text-right"><b>41,306.00</b></td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" class="text-right">Add - SAC- 998551- CGST(9%) 347.04 + UTGST (9%) 347.04</td>
                                                <td class="text-right">694.08</td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" class="text-right">Rounded Off</td>
                                                <td class="text-right">-0.08</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="padding:5px 0px;" colspan="2">
                    <table class="total-wrap">
                        <tbody>
                            <tr>
                                <td style="border-top: 2px solid #ccc;border-bottom: 2px solid #ccc;">{{@strtoupper($data->currency_type)}}. Forty Two Thousand Only</td>
                                <td style="border-top: 2px solid #ccc;border-bottom: 2px solid #ccc; text-align:right;"><b>Net Amount</b></td>
                                <td style="border-top: 2px solid #ccc;border-bottom: 2px solid #ccc; text-align:right;"><b>42,000.00</b></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        @else
            <tr>
                <td colspan="2">
                    <table class="border-table text-left">
                        <thead class="head-table text-left">
                            <tr>
                                <th>Package Name</th>
                                <th>Package Duration</th>
                                <th>Basic</th>
                                <th>Taxes</th>
                                <th>Total ({{@strtoupper($data->currency_type)}})</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{{$data->package_title}}</td>
                                <td>{{$data->package_duration}}</td>
                                <td>{{@number_format($data->package_price)}}</td>
                                <td>1,928.00</td>
                                <td>20,653.00</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <table class="total-wrap">
                        <tbody>
                            <tr>
                                <td style="width:50%;">
                                </td>
                                <td>
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td style="text-align:right;" class="text-right"><b>Total</b></td>
                                                <td style="text-align:right;" class="text-right"><b>37,450.00</b></td>
                                                <td style="text-align:right;" class="text-right"><b>3,856.00</b></td>
                                                <td style="text-align:right;" class="text-right"><b>41,306.00</b></td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" class="text-right">Add - SAC- 998551- CGST(9%) 347.04 + UTGST (9%) 347.04</td>
                                                <td class="text-right">694.08</td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" class="text-right">Rounded Off</td>
                                                <td class="text-right">-0.08</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="padding:5px 0px;" colspan="2">
                    <table class="total-wrap">
                        <tbody>
                            <tr>
                                <td style="border-top: 2px solid #ccc;border-bottom: 2px solid #ccc;">{{@strtoupper($data->currency_type)}}. Forty Two Thousand Only</td>
                                <td style="border-top: 2px solid #ccc;border-bottom: 2px solid #ccc; text-align:right;"><b>Net Amount</b></td>
                                <td style="border-top: 2px solid #ccc;border-bottom: 2px solid #ccc; text-align:right;"><b>42,000.00</b></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        @endif
        <!-- <tr>
            <td style="padding:5px 0px;line-height: 22px;" colspan="2">
                <b>E. & O. E.</b>
                <br/>This is Abshiskek and I will be working with you to plan your trip to Europe.
                <br/>Please find the below details your trip & for further discussions, feel free to call me 5555555555.
                <br/>This is Abshiskek and I will be working with you to plan your trip to Europe.
                <br/>Please find the below details your trip & for further discussions, feel free to call me 5555555555.
            </td>
        </tr>
        <tr>
            <td colspan="2"><hr class="line1" /></td>
        </tr> -->
    </tbody>
</table>