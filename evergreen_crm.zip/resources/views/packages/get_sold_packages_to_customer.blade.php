<style type="text/css">
    .tab-content{
            padding:28px 0px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap h4{
        padding:0px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul{
        background-color: transparent;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li{
        border:none;
    }
    .nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover, .nav-tabs>li>a:hover{
        color: #fff;
        background: transparent!important;
    }
    .nav-tabs>li>a{
        color: #b5b5b5;
        background-color: transparent;
        padding: 23px 30px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li{
        background:#333333;
        padding: 0px;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li.active, .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li:focus, .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li:hover, .dashboard-list-box.sold_packages_and_booked_flights_wrap ul li:hover{
        background:#005294;
        color:#fff!important;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap h4.gray{
        background:transparent;
        border:none;
    }
    .dashboard-list-box.sold_packages_and_booked_flights_wrap ul{
        border:none;
    }
</style>
<div class="table-box" style="width:100%;">
    <div class="dashboard-list-box sold_packages_and_booked_flights_wrap">
        <h4 class="gray">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#imported">Sold Packages</a></li>
                <li><a data-toggle="tab" href="#rejected">Booked Flights</a></li>
            </ul>
        </h4>
        <div class="tab-content">
            <div id="imported" class="tab-pane fade in active">
                <div class="table-responsive">
                    <table class="basic-table booking-table table-condensed">
                        <thead>
                            <tr>
                                <th>Package Name</th>
                                <th>Package Duration</th>
                                <th>Package Price</th>
                                <th>Departure Date</th>
                                <th>Sold Date</th>
                                <th>Inclusion/Exclusion</th>
                                <th>Actions</th> 
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($sold_packages_arr) > 0)
                                @foreach($sold_packages_arr as $sold_package)
                                    <tr>
                                        <td>{{$sold_package->package_title}}</td>
                                        <td>{{$sold_package->package_duration}}</td>
                                        <td>
                                            @php echo Config::get('constants.CURRENCY_TYPE.'.$sold_package->currency_type);echo number_format($sold_package->package_price); @endphp
                                        </td>
                                        <td>{{@date('j M, Y', @strtotime($sold_package->package_departure_date))}}</td>
                                        <td>{{@date('j M, Y', @strtotime($sold_package->created_at))}}</td>
                                        <td>
                                            @php 
                                                $inclusion_arr = array();
                                                $exclusion_arr = array();
                                                if(!empty($sold_package->inclusion)) {
                                                    $inclusion_arr = unserialize($sold_package->inclusion);
                                                    if(!is_array($inclusion_arr)) {
                                                        $inclusion_arr = array($inclusion_arr);    
                                                    }
                                                }
                                                if(!empty($sold_package->exclusion)) {
                                                    $exclusion_arr = unserialize($sold_package->exclusion);
                                                    if(!is_array($exclusion_arr)) {
                                                        $exclusion_arr = array($exclusion_arr);    
                                                    }
                                                }
                                            @endphp
                                            <a style="background-color:#468c21;" data-toggle="tooltip" data-placement="top" data-html="true" title="@if(!empty($inclusion_arr))@foreach($inclusion_arr as $key => $inclusion) {{$inclusion}} <br> @endforeach @endif" href="javascript:;" class="button gray"><i class="fa fa-check"></i></a>
                                            <a style="background-color:#d60d45;" data-toggle="tooltip" data-placement="top" data-html="true" title="@if(!empty($exclusion_arr))@foreach($exclusion_arr as $key => $exclusion) {{$exclusion}} <br> @endforeach @endif" href="javascript:;" class="button gray"><i class="fa fa-close" aria-hidden="true"></i></a>
                                        </td>
                                        <td>
                                            <a style="" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="{{url('/download_invoice')}}/{{$sold_package->id}}/{{$sold_package->customer_id}}/package" class="button gray enabled" data-original-title="Download Invoice"><i class="fa fa-download"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            @else 
                                <td colspan="6" class="no-data-found">No Package has been sold yet.</td>
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="rejected" class="tab-pane fade">
                <div class="dashboard-list-box sold_packages_and_booked_flights_wrap">
                    <div class="table-responsive">
                        <table class="basic-table booking-table table-condensed">
                            <thead>
                                <tr>
                                    <th>Ticket No.</th> 
                                    <th>PNR No.</th>   
                                    <th>Airways</th>
                                    <th>Price</th>   
                                    <th>Flight Details</th> 
                                    <th>Actions</th>         
                                </tr>
                            </thead>
                            <tbody>
                                @if(count($booked_flights_arr) > 0)                
                                    @foreach($booked_flights_arr as $booked_flight)
                                        <tr>
                                            <td>{{$booked_flight->ticket_number}}</td>
                                            <td>{{$booked_flight->pnr_number}}</td>
                                            <td>{{$booked_flight->airways_name}}</td>
                                            <td>@php echo Config::get('constants.CURRENCY_TYPE.'.$booked_flight->currency_type);echo number_format($booked_flight->price); @endphp</td>
                                            <td>
                                                <div>
                                                    {{$booked_flight->flight_from}} <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> {{$booked_flight->flight_to}} ({{date('d, M Y', @strtotime($booked_flight->departure_date))}})
                                                </div>
                                                @if($booked_flight->flight_type == 'round_trip')
                                                    <div>
                                                        {{$booked_flight->flight_to}} <i class="fa fa-long-arrow-right" style="color:#D60D45;" aria-hidden="true"></i> {{$booked_flight->flight_from}} ({{date('d, M Y', @strtotime($booked_flight->arrival_date))}})
                                                    </div>
                                                @endif
                                            </td>
                                            <td>
                                                <a style="" data-toggle="tooltip" target="_blank" data-placement="top" title="" href="{{url('/download_invoice')}}/{{$booked_flight->id}}/{{$booked_flight->customer_id}}/flight" class="button gray enabled" data-original-title="Download Invoice"><i class="fa fa-download"></i></a>
                                            </td>
                                        </tr>
                                    @endforeach  
                                @else 
                                    <td colspan="7" class="no-data-found">No Flight has been booked yet.</td>
                                @endif 
                            </tbody>
                        </table>
                    </div>
                </div>
        </div>
    </div>
</div>
<script trype="text/javascript">
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script>