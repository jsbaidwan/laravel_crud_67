@php 
if(!empty($package_data)) {
    preg_match_all('!\d+!', $package_data->duration, $duration);
    $package_data->days = $duration[0][0];
    $package_data->nights = $duration[0][1];
}
@endphp
{!! Form::model($package_data, ['route' => 'save_package', 'id' => 'add-package-form']) !!}
    {!! Form::hidden('id', null) !!}
    <div class="my-profile">
        <label>Title</label>
        {!! Form::text('title', null, ['class' => 'form-control validate[required]', 'required' => true]) !!}
        <!-- <label>Tour Location</label>
        {!! Form::text('location', null, ['class' => 'form-control validate[required]', 'required' => true]) !!} -->
        <label>Duration</label>
        <div class="row">
            <div class="col-md-6" style="columns:2">
                {!! Form::text('days', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]]', 'required' => true]) !!}
                <p>Days</p>
            </div>
            <div class="col-md-6" style="columns:2">
                {!! Form::text('nights', null, ['class' => 'form-control validate[required,custom[onlyNumberSp]]', 'required' => true]) !!}
                <p>Nights</p>
            </div>
        </div>
        <label>Departure date</label>
        <div class="input-group date">
            {!! Form::text('departure_date', null, ['class' => 'form-control validate[required] datepicker']) !!}
            <div class="input-group-addon">
                <i class="fa fa-calendar" aria-hidden="true"></i>
            </div>
        </div>  
        <label>Price</label>
        {!! Form::text('price', null, ['class' => 'form-control validate[required]', 'required' => true]) !!}
        <label>Select Currency</label>
        {!! Form::select('currency_type', Config::get('constants.CURRENCY_TYPE_LIST'), null, ['class' => 'browser-default custom-select form-control validate[required]', 'required' => true]) !!}
        @if(empty($package_data)) 
            <label>Inclusion (Add multiple enteries by pressing enter key.)</label>
            {!! Form::textarea('inclusion', null, ['class' => 'form-control text-area-field', 'rows' => '3']) !!}
            <label>Exclusion (Add multiple enteries by pressing enter key.)</label>
            {!! Form::textarea('exclusion', null, ['class' => 'form-control text-area-field', 'rows' => '3']) !!}
        @endif            
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.datepicker').datepicker({
                autoclose: true
            });
        });
    </script>
{!! Form::close() !!}